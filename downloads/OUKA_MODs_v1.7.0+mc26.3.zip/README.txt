OUKA V1.7.0
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある 2 つの jar を、Minecraft の mods フォルダーに入れる。
   - ouka-1.7.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Fabric API を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ 2 つと Fabric API を入れる。

■ ご注意
- GeckoLib はこの zip に同梱しています。ほかの MOD が同じ GeckoLib を入れている場合は、
  どちらか 1 つだけを残してください。2 つあると起動しません。
- 前の版から入れ替えるときは、古い OUKA の jar(ouka-1.6.2.2+mc26.3.jar・ouka-1.6.2+mc26.3.jar・ouka-1.6.1+mc26.3.jar・ouka-1.6.0.1+mc26.3.jar・ouka-1.6.0+mc26.3.jar・ouka-1.5.0+mc26.3.jar・ouka-1.4.0+mc26.3.jar・ouka-1.3.1+mc26.3.jar・ouka-1.3.0+mc26.3.jar・
  ouka-1.2.0+mc26.3.jar・ouka-1.1.0+mc26.3.jar・ouka-1.0.1+mc26.3.jar など)を mods フォルダーから消してください。
  OUKA の jar が 2 つあると起動しません。
- V1.4 と V1.5 の世界はそのまま開けます。ただし、V1.4 で置いた組立ラインは、製品が選ばれていない状態で読み込まれ、
  製品を選ぶまで待機します(下の「組立ライン」の節)。
- 設定ファイルはありません。新しいキーも、新しいコマンドもありません(V1.6.0)。OP 用のコマンドは 2 つです(/ouka reload と /ouka mount)。
- V1.6.0 は OUKA 単独で動きます。ほかの MOD の武器との互換はありません。
- この版は Minecraft 26.3 専用です。
- V1.6.0 で遊んだあと V1.5.0 に戻すと、V1.6.0 の新しいブロックと品(和室の品・重工業の機械と材料)がワールドから消えます(MOD の通常の動き)。
  戻すことは想定していません。
- V1.6.1 で新しい鍵(既定は J・U・I)と、OP 用のコマンド /ouka sorcery が増えました(下の V1.6.1 の節)。
- V1.6.2 で新しい品 6 つとブロック 3 つ(流星: 超伝導リニアの列車)が増えました(下の V1.6.2 の節)。
- V1.6.2.2 は触媒熱化学溶鉱炉の燃料・材料の緩衝・手回し発電機の追加です(下の V1.6.2.2 の節)。
- V1.6.2.1 は流星の説明の手直しです(下の V1.6.2.1 の節)。
- V1.7.0 で Limitless(五条と宿儺の術式・領域展開・Kamutoke・Hiten)が入りました。新しい鍵が 5 つ(既定は R・Z・V・X・C)増えます(下の V1.7.0 の節)。

■ V1.7.0 —— Limitless
- 五条と宿儺の術式が使えます。R で能力を切り替え、Z と V で使い、X で選びを戻し、C で術式のメニューを開きます。
  鍵は「操作設定」の Limitless の欄で変えられます。
- 五条: 無下限(Infinity)、Lapse Blue、Reversal Red、Hollow Purple、領域 Infinite Void(Domain Expansion)。
- 宿儺: Dismantle、Cleave、Open、領域 Malevolent Shrine。武器の Kamutoke は雷を落とします。
- 品: Kamutoke・Hiten・Blindfold・Character Guide と、6 種のスポーンエッグ。ブロック: Domain Barrier(壊せず、爆発でも消えない)。
  Blindfold は黒い羊毛 3 つで作れます。Character Guide は初めて入ったときに 1 冊もらえ、術式の説明が読めます。
- 名前は源の英語のままです。
- 既知の不具合: 画質の設定「Improved Transparency」をオンにすると(既定はオフ)、Hollow Purple の球が水の奥ではなく
  手前に描かれます。1.7.1 で直します。オフのときは正しく描かれます。
- 1.7.0 で遊んだあとに前の版へ戻すと、Domain Barrier と Limitless の品がすべて世界から消えます(MOD の通常の動き)。

■ V1.6.2.2 —— 溶鉱炉の燃料・組立ラインの材料の緩衝・手回し発電機(仮の数字)
- 触媒熱化学溶鉱炉: 生のタングステン鉱石(粉砕する前のもの)を、アルゴンの缶 1 つで直接インゴットにできます。
  タングステンのインゴット 2 つ、160 歩(仮)。古代の残骸は、アルゴンの缶 1 つでネザライトのくず 1 つ(バニラと同じ数)、160 歩(仮)。
  アルゴンの缶は、機械の右の燃料の枠に入れます。燃料の枠は、アルゴンの缶だけを受けます。ホッパーはアルゴンを燃料の枠へ、材料を入口へ入れます。
  燃料が無いと、生の鉱石を取らず、「燃料を待っている」と出ます。
- 高精度オートメーション組立ライン: 材料の緩衝という 18 枠を足しました(仮)。どの組立レシピの部品でも、選んでいなくても入ります。画面の枠に手で入れておけば、あとからレシピを選んでそのまま作れます(ホッパー・コンベアは今までどおり入口へ入れます)。
  作るときは、入口で揃えばそこから、揃わなければ緩衝から取ります。取る数はレシピどおりで、足りなければ何も取りません。
  作る品の一覧では、緩衝の中身だけで今すぐ作れる品の下の縁に緑の線が出ます。画面を開いたままでも、部品を入れ替えると線の出方が変わります。
- 手回し発電機(新しいブロック・仮): 右クリックで回します(押し続ければ回り続けます)。1 回で、6 歩のあいだ、1 歩 4,000 J(仮)、
  パイロンの網へ電気を出します。使われなかった電気は捨てられます。回すと、少しだけ疲れます。
  作り方はバニラの材料だけ(棒・鉄のインゴット・ピストン)。最初の電力に使えます: 手回し発電機 → テスラ・パイロン(オウカ合金のインゴットは
  バニラの材料から作れます)→ 水圧粉砕機。
- 数字はすべて仮です。疲れの量は試験で見ていません。

■ V1.6.2.1 —— 流星の説明の手直し
- 効果の列の桜花の加護のアイコンは残しています。アイコンにマウスを乗せると、いま効いているオーラの系統ごとに、Lv と効き目が出ます。
  画面右上のオーラの表は出しません。オーラの効果は今までどおり働きます。
- 流星の品の説明に、運行の要約を足しました: 列車は駅のあいだを自動運転(ATO)で往復すること、手ぶらで運行指令盤を使うと運転を始める・止めること、
  先頭車か展望車の席に座ると計器が見えること。
- 車両の品をブロックに使うと、線路には置けないと画面の下に知らせます。編成票を運行指令盤以外のブロックに使ったときも、同じように知らせます。
- 次の駅が線の端に近すぎて列車が収まらないときは、乗っている人に理由を知らせます(以前は、扉が閉まって開き直すだけで何も知らせませんでした)。
  停止コイルを置いたとき、素手で使ったとき、指令盤に編成票を使ったときも、同じ理由を知らせます。

■ V1.6.2 —— 流星(超伝導リニアの列車)の追加
- 新しい品 6 つと、新しいブロック 3 つを足しました。列車は 4 つの車両(先頭車・客車・展望車・電源車)でできています。
  品は、流星の測量器・先頭車・客車・展望車・電源車・編成票の 6 つです。ブロックは、ガイドウェイの節点・停止コイル・運行指令盤の 3 つです。
- 始め方:
  1. 流星の測量器を、ガイドウェイの節点に 1 つずつ使って結ぶ。結べる線には、節点の間隔・曲がりの半径・坂の勾配に決まりがあります。
     つなげない理由は測量器が言います。結ぶたびに、線の長さ・いちばん急な曲がり・線の上の速さを知らせます。
  2. 線の近くに停止コイルを置くと、そこが駅になります。列車は、コイルの所で中央を止めて、コイルの側の扉を開けます。
  3. 運行指令盤を停止コイルの近くに置きます。編成票を運行指令盤に使うと、その駅に列車を置きます。
     手ぶらで使うと、駅のあいだの往復運転を始める・止めます。しゃがんで手ぶらで使うと、待っている空の列車を編成票に戻します。
  4. 先頭車の運転席に座ると、速さ・インバータの周波数・架線の電圧を読めます。
- 乗り降り: 扉が開くのは、列車が止まっていて、停止位置にいるときだけです。走っているあいだは扉に鍵がかかります。
  座席は使うと座り、しゃがむと立ちます。走っているあいだも車内の通路を歩けます。
- 線の上に物があると、列車はその手前で止まって待ちます。列車はブロックを壊しません。
- 給電ブロックと電力網は、まだありません。運転台の電圧と周波数は、見た目の飾りです。
- V1.6.2 で遊んだあと V1.6.1 に戻すと、流星の品とブロックがワールドから消えます。戻すことは想定していません。

■ V1.6.1 —— 霊脈機関(魔術)の追加
- 新しい品 4 つと、結界の印(ブロック)1 つを足しました。品は、組立ラインで製品に選んで作ります(作業台のレシピではありません)。
  品は、銀の祭刀・地紋の焦点・霊眼のレンズ・結界の白墨の 4 つです。結界の白墨は、ブロックの上の面に結界の印を描きます。
- 始め方:
  1. 銀の祭刀をしゃがんで使うと血の儀を行う。少しの体力を払い、霊脈が開く。体力が少ないときは断られる(死なない)。
     クリエイティブでは体力を払わない。
  2. 霊脈の容量が育ったら、もう一度血の儀を行うと次の段へ上がる。段は自動では上がらない。
  3. 地紋の焦点を主の手に持つ。既定の J を押し続けると幻刃の雨。既定の I で霊脈の状態(霊力・段・育ち具合)を見る。
  4. 霊眼のレンズは、右クリックを押し続けて覗く。既定の U で霊眼を切り替える(静止の霊眼は段 3 から、看破の霊眼は段 4 から)。
     レンズはどちらの手でも使える。
  5. 結界の白墨は段 2 から。ブロックの上の面に印を描き、地紋の焦点で霊力を注ぐ。
- 霊力: 霊脈は時間とともに霊力が戻ります。霊力をほぼ満ちた所から魔術でほぼ空まで使い切ると、容量が育ちます。
  戻り方と育ち方の数は、データ(data/ouka/sorcery)で変えられます。
- 幻刃の雨: 幻刃は視線の先へ飛び、刺さり、少し遅れて爆ぜます。幻刃も爆ぜも、ブロックを壊しません。
- 結界の印の操作: 素手で印を使うと、警報・吸命・遮断が替わります。白墨で使うと、届く広さが替わります。
  銀の祭刀で使うと、登録した人を空にします。印は誰でも壊せます(白墨が 1 本落ちる)。
- 結界の数: 1 人が持てる結界の数には上限があり、段が上がると増えます。地紋の焦点で霊力を注ぐとタンクが満ちます。
  タンクが空になると、結界は崩れます。
- 結界の働き(できること・できないこと):
  - 警報結界: 登録していない人と、敵対する生き物が中へ入ったことを知らせる。
  - 吸命結界: 登録していない人と敵対する生き物から体力を吸い、霊力に変える。プレイヤーは体力を吸い尽くされない。
  - 遮断結界: 結界の外から中へ飛んでくる飛び道具と爆発の傷を、タンクの霊力で止める。近接・魔法・落下の傷と、爆風の押しは止めない。
  - 結界は人を閉じ込めず、通行を止めず、ブロックも守らない。
  - 登録: 持ち主が地紋の焦点を主の手に持って近くにいるとき、ほかの人は素手で印を使うと登録される(人数に上限あり)。
- 霊眼(段 3 と 4):
  - 静止の霊眼: 見ている生き物を、近くで少数まで止める(速さを 0 にする)。ボスには効かない。プレイヤーには
    PvP が通るときだけ、短い間止め、そのあとしばらく効かない。空中の的はゆっくり沈む(既知の限界)。
  - 看破の霊眼: OUKA の銃と幻刃が弱点(既定は頭)に当てた一撃を大きく強める。ボスには 1 発で与えられる量に上限がある。
    プレイヤーには強まらない。
  - レンズを持つと、敵対する生き物とボスを壁越しに枠で示す(プレイヤーは示さない)。開いている間は霊力を使う。
- 鍵 J・U・I は既定の割り当てです。「操作」の「OUKA 霊脈機関」で変えられます。
- V1.6.0.1 の世界はそのまま開けます。V1.6.1 で遊んだあと V1.6.0.1 に戻すと、結界の印と新しい 4 つの品がワールドから消えます
  (MOD の通常の動き)。戻すことは想定していません。
■ V1.6.0.1 —— 調整と追加(2026-10-12)
- 火山熱水式 造石・超粉砕機で、粘土が作れるようになりました。画面の「作るもの」に「粘土」が加わります(1 個 1.6 秒。
  丸石・砂利・砂・鉱砂と同じく、溶岩と水は減りません)。
- 電気を使う機械の消費電力を、すべて 2 倍にしました(V1.2〜V1.3 の機械、タキオン加速コア、V1.6.0 の重工業の機械)。
  発電と蓄電の定格(風車・太陽熱・核分裂炉・人工太陽・SMES・フライホイール・溶融塩)は変えていません。
  いまの工場は、同じ発電では半分の台数しか回りません。足りない機械は、器が空になると止まって待ちます(壊れません)。
- OUKA ビーコンの効果の上限を 20.00 から 5.00 に下げました(4 分の 1)。すでに 5.00 を超えて設定してあるビーコンは、
  読み込んだときに 5.00 になります。半径 1,000 ブロックと台座 328 個は変わりません。
- OUKA ビーコンの作り方を半分にしました: ビーコン 2・桜花合金ブロック 2・ネザースター 1(これまではビーコン 4・桜花合金ブロック 4・
  ネザースター 1)。作業台で、上下に桜花合金ブロック、左右にビーコン、中央にネザースターです。
- V1.6.0 の世界はそのまま開けます。新しいブロックも品もありません。

■ V1.6.0「The Grand Synthesis」—— 和室の隙の修正と調度品 50 種・重工業の機械 30 種・材料 32 種
- 和室: 障子と襖のすき間をふさぐ修正と、溝つき桧の敷居、新しい和室の品 50 種(敷居を含めて 51 ブロック)。
- 重工業: 機械 30 種と、新しい材料 32 種。設備は真空・空気・冷却材・清浄の 4 種で、一部の機械は、必要な設備を隣に接する機械から受けて動きます。
- 新しいブロックは 81 種、品は 113 種(ブロックの品と材料)、新しい音は 73 種です(下の「音」の節)。
- 新しいキーも、新しいコマンドも、設定ファイルもありません。

■ 和室: すき間をふさぐ修正と、溝つき桧の敷居(V1.6.0)
- 隣り合う障子・襖のあいだに、光が通るすき間がありました。V1.6.0 では、桟の奥側のパネルの両端に、すき間をふさぐ材を入れました。
  当たり判定・レール・レシピ・スライドの動きは変えていません。
- 溝つき桧の敷居(shikii_sill)を新しく入れました。障子や襖の下に置く敷居です。
- ふさぐ材は見た目だけです。照準と弾は今までどおり、溝の間の 3 ピクセルのすき間を通ります。和紙が少し透けること、格子やガラスの向こうが見えることは設計どおりです。
  開けた戸の見え方は、この修正の対象外です。

■ 和室: 調度品 50 種(V1.6.0)
- 戸・窓・仕切り(11 種): 菱格子障子、雪見障子(ガラスが上にすべります)、太鼓襖、御簾、千本格子戸、麻の葉組子障子、雨戸、格子窓、丸窓、衝立、枕屏風。
- 床の間と座敷(12 種): 花梨の一枚板飾り台、銘木違い棚、螺鈿細工文机、付書院、純金茶釜、青銅製釣灯籠、衣桁、見台、お膳、徳利と盃、床框、積み布団。
- 囲炉裏と台所(3 種): 囲炉裏、自在鉤と鉄鍋、火鉢。
- 庭(16 種): 白砂利波紋、砂紋の縁石、立石・三尊石組、立石(高)、飛石、敷石、苔山、竹垣(密)、四ツ目垣、枝折戸、蹲、筧、水琴窟、井筒と釣瓶、朱塗り欄干、盆栽。
- 灯り・音・季節(8 種): 置灯籠、提灯、ガラス風鈴、太鼓、琴、門松、達磨、鯉のぼり。
- 自分の音を持つ品は 7 種です(太鼓・琴・水琴窟・ガラス風鈴・白砂利波紋・雪見障子・雨戸。音は合わせて 10 種)。新しい音は全部で 73 種です(下の「音」の節)。

■ 重工業: 機械 30 種と材料 32 種(V1.6.0)
- 機械は 30 種です。模型は GeckoLib で描いています。
- 設備は真空・空気・冷却材・清浄の 4 種です。一部の機械は、必要な設備を送る機械(真空ポンプ・ガス圧縮機・冷却材循環ポンプ・
  クリーンルーム・ファンフィルターユニット)が隣に接するまで待機します。設備の要らない機械もあります。
- 人工太陽磁気核融合炉は 7 x 7 x 7 ブロックです。出力の上限は 1.00 GW(毎 tick 50,000,000 J)です。
- 重力遠心気相分離塔は、希ガスの缶からアルゴンの缶と、ヘリウム 3 の缶を作ります。
- 材料は機械の工程で作ります(タングステン原石だけは、地殻深層掘削クァーリーから出ます)。タングステン(原石・粉・インゴット・板)、超高純度チタンのインゴット、チタンの板、超微粉 5 種、
  グラフェンシート、カーボンプレート、炭化タングステンの鋳片と板、ガスの缶 6 種(液体酸素・希ガス・アルゴン・合成ガス・灯油・ガソリン)、
  重水素セル、耐火レンガ、触媒ペレット、スラグ、硝酸塩、シリコンウェハー、微細回路基板、量子チップ、精密モジュール、超伝導コイル、電解銅板。
- 機械の作り方は組立ラインのレシピです(30 件)。作業台の 3 x 3 のレシピには出ません。

■ V1.5.0「The Wrought Iron Sovereign Update」—— 鋼鉄の守護騎士・宝物庫の扉・大断頭斧・重鉄の防壁・組立ラインの製品選択
- 新しいボス「鋼鉄の守護騎士」と、その彫像「鋼鉄の守護騎士の彫像」。
- 宝物庫の強化扉と宝物庫の総鍵。守護騎士の大断頭斧。重鉄の防壁インゴットと、重鉄の防壁の防具 4 点。
- 高精度オートメーション組立ラインは、選んだ製品だけを作るようになりました(修正)。
- 新しい品は 10 種、新しいブロックは 2 種、新しい音は 15 種です(下の「音」の節)。

■ 鋼鉄の守護騎士(ボス)
- 高さ 3.8 ブロック、体力 300(ハート 150 個)。自然には出現しません。スポーンエッグか /summon で置きます。
- 最初は眠っていて、彫像のように動きません。サバイバルかアドベンチャーの生きているプレイヤーが 8 ブロック以内に近づくか、だれかが攻撃すると目を覚まします。
  目を覚ますと、倒されるまで眠りません。体力のゲージは、目を覚ましてから、64 ブロック以内のプレイヤーに表示されます。
- 目を覚ましているあいだは、どの方向からの攻撃も受け流します。ダメージは通らず、当たった数にも数えません。背中からの攻撃も同じです。
  - 振り下ろしのあと、斧が地面に刺さっている約 3.5 秒のあいだだけ、背中が開きます。この間も、正面と両側からの攻撃は受け流します。
  - 開いているあいだに通るのは、真後ろを中心とした水平方向 145 度の範囲からの攻撃だけです。ダメージは 5 倍になります。
  - 1 回の開きで通るダメージは 100 までです。100 に達すると、その開きは終わります。そのため、倒すには少なくとも 3 回の開きが要ります。
  - 須佐之男(Type-50)の弾と、サークル弾の衝撃波(着弾した場所から広がる輪)は、開きのあいだ背後から当たると 60 ダメージです(5 倍にはなりません)。
- 攻撃の仕方(ダメージは難易度と防具で変わります):
  - 振り下ろし: 斧を地面に打ちつけ、近くの生き物に 14 ダメージを与えて外へ吹き飛ばします。地面に一時的な亀裂が出ますが、ブロックは壊れません。
  - 斧の引き抜きとなぎ払い: 斧を抜いて、近くの生き物に 10 ダメージを与えます。
  - 盾打ち: 前方の近くの生き物に 8 ダメージを与えます。
- 倒すと、必ず宝物庫の総鍵 1 個・大断頭斧 1 本・重鉄の防壁インゴット 8 個が出ます(経験値 400 も)。

■ 鋼鉄の守護騎士の彫像
- 3 x 3 x 4 ブロックの彫像です。眠っている守護騎士と同じ姿で、動かず、目を覚ましません。
- 置くには、その周りの 3 x 3 x 4 の空間が空いている必要があります。
- どの部分を壊しても、彫像全体が壊れ、彫像が 1 個出ます。
- 作り方: 組立ラインで 機械の骨組み 2・複合素材の板 12・鉄板 24・桜花合金板 4 → 彫像 1 個。ボスからは出ません。

■ 宝物庫の強化扉と宝物庫の総鍵
- 扉は 2 ブロックの高さです。宝物庫の総鍵を持って右クリックすると開き、もう一度右クリックすると閉じます。
  総鍵は減らず、耐久もありません。
- 鍵を持っていないと開きません。「鍵がかかっている。宝物庫の総鍵でだけ開く。」と出ます。
- どの宝物庫の総鍵も、どの宝物庫の扉も開けます。扉と鍵は組になっていません。
- サバイバルでは壊せません。爆発・ウィザー・エンダードラゴンでも壊れません。クリエイティブでは壊せますが、何も出ません。
- 扉を置けるのは OP だけです。ほかの人は置けず、品を持ったままになります。扉にも総鍵にも作り方はありません。
  総鍵は守護騎士を倒したときだけ出ます。扉はクリエイティブのタブか /give で渡されます。
- レッドストーンでは開きません。

■ 守護騎士の大断頭斧
- 近接武器です。攻撃力 13、耐久 1800。金床で重鉄の防壁インゴットを使って修理できます。作り方はありません。
- 右クリックを 1.2 秒押し続けてから離すと、衝撃波が出ます。1.2 秒より前に離すと何も起きません。
  - 向いている方向の扇形(左右それぞれ 40 度)・前方 6 ブロック・上下 3 ブロックに届きます。
  - 14 ダメージを与え、当たった相手を 2 秒のあいだ動けなくして、押し飛ばします。
  - 使うたびに 8 秒のクールダウンがあり、耐久が 1 減ります。
  - ブロックは壊れず、地面も変わりません。使った人自身と、その人がてなずけた動物には当たりません。
- 守護騎士に対しては、ボスの規則どおりです。正面と両側は受け流し、背中が開いているあいだは後ろから 70 ダメージ。気絶はしません。

■ 重鉄の防壁(インゴットと防具)
- 重鉄の防壁インゴットは、守護騎士を倒したときだけ出ます(1 回に 8 個)。作り方はありません。火に強いです。
- 防具は 4 種類: 兜・胸当て・脚甲・靴。防御力は 3・8・6・3(合計 20)。どの 1 点も、ノックバックへの耐性が 0.25 あります。
  4 点すべてを身につけると、ノックバックを受けません。守護騎士の攻撃のダメージは、防具の分だけ減って通ります。
- 作り方(組立ラインで 1 点ずつ):
  - 兜: 重鉄の防壁インゴット 4・複合素材の板 2・電子回路 1
  - 胸当て: 重鉄の防壁インゴット 6・機械の骨組み 1・複合素材の板 4・電子回路 1
  - 脚甲: 重鉄の防壁インゴット 5・複合素材の板 3・工業用プラスチック 2
  - 靴: 重鉄の防壁インゴット 3・複合素材の板 2・工業用プラスチック 1・鉄板 2
- 4 点そろえるにはインゴットが 18 個要るので、守護騎士を 3 回倒す必要があります。

■ 組立ライン: 選んだ製品だけを作ります(V1.5.0 の修正)
- V1.4.0 までは、組立ラインに製品を選ぶ方法がありませんでした。部品がそろった最初のレシピを名前順で選んでいたため、
  V1.4.0 の組立レシピ 42 種のうち 16 種は、正しい部品だけを入れても、別の品が出ていました(銃 11 丁・パーツ、道具、防具 5 点)。
- 製品を選ぶ画面が加わりました。何も取り出すものがないとき、空の手で組立ラインを使うと開きます。
  ラインが受け付けない品を持って使っても開きます。製品の一覧から選び、「これを作る」を押すまでは、何も変わりません。
- 選んだ製品の部品だけを受け付けます。手で入れても、ホッパー・コンベア・パイプで入れても同じです。
  選び直すと、新しい製品に使わない部品は、ボタンを押した人に戻ります。「選択を外す」で、中の部品はすべて戻ります。
- 選択は組立ラインに保存されるので、再起動や、チャンクの読み込み直しのあとも残ります。壊して持ち運んだ場合も、
  アイテムに選択が残ります。
- 組立ラインの外枠(狙ったときに出る枠)を、描かれた機械の形に合わせました。機械の大きさと当たり判定は変わっていません。
- 選んだレシピをデータパックが消すと、ラインは「選んだ品のレシピがない」と表示して止まり、部品は残ります。
- V1.4 の世界: V1.5.0 より前に置いた組立ラインは、製品が未選択の状態で読み込まれ、待機します。
  部品・完成品・作業中の品・蓄えた電力は失われません。ただし、製品を選ぶまで部品を受け付けないので、
  ホッパーやコンベアがつまります。各ラインを一度開いて製品を選んでください。

■ V1.4.0「The Kinetic Overdrive」—— 銃 15 丁・パーツ 14 種・風力発電機・色つきシェルターガラス
- 新しい動きの仕組み「OKE」: リグ(骨組み)とバネで動きを作る、OUKA の新しい描画の仕組みです。銃と風力発電機の動きを担い、
  物質トランシーバーの描画も OKE に移りました。GeckoLib は引き続き必要です(ほかの機械はまだ GeckoLib で描いています)。
- 新しい品は 43 種(銃 15・弾 6・パーツ 14・風力発電機 1・シェルターガラス 7)。銃とパーツはクリエイティブの OUKA のタブにあります。
- 新しい音は 177 種(下の「音」の節)。
- V1.3.1 の直しも入っています。

■ 銃(OUKA GUN MAX): 15 丁
- 銃は精密組立ラインで作ります。弾は 6 種類で、作業台で作れます(軽量弾・重量弾・エネルギー弾・散弾・狙撃弾・神話弾)。
  リロードは持ち物の弾を使います。クリエイティブでは弾は減りません。
- 15 丁(名前は ゲーム内の表示どおり):
  01 Type-01「草薙」カービン / 02 Type-47「雷神」重突撃銃 / 03 Type-99「隼」高速連射短機関銃 / 04 Type-09「雷切」プラズマ短機関銃 /
  05 Type-88「村正」二口径短機関銃 / 06 Type-12「浪人」レバーアクション散弾銃 / 07 Type-08「竜巻」ドラム式自動散弾銃 /
  08 Type-04「鬼火」横一文字散弾銃 / 09 Type-44「小次郎」大口径ハンドキャノン / 10 Type-77「月光」増幅式ボルトアクション狙撃銃 /
  11 Type-50「須佐之男」対物キャノン / 12 Type-55「不動」重装軽機関銃 / 13 Type-24「迦具土」加速型軽機関銃 /
  14 Type-03「三星」三連コアマークスマン / 15 Type-20「雀蜂」戦術連射ピストル(どれも名前の頭に「OUKA」が付きます)
- 銃ごとに専用の仕掛けがあります。雷切は撃つほど熱がたまり、リロードで排熱します。村正は N キーで軽量弾と重量弾を切り替えます。
  月光は N キーでエネルギーをため、次の 1 発の威力が 2 倍になります。迦具土は撃ち続けると連射が 330 発/分から 900 発/分まで上がります。
  不動は撃ち続けるほど反動が収まります。鬼火の散弾は当たった相手に火をつけます(ブロックは燃えません)。
  三星は 3 本の弾を平行に撃ちます。須佐之男は、ボス以外の生き物を 1 発で倒し(ボスには最大体力の 2 割)、射程は 1,024 ブロックです。
- 弾は 50 ブロックまで即着弾し、それより先は重力と空気抵抗で落ちながら飛びます。木の扉・ガラス・鉄格子・和室の障子や襖などは、
  威力を落として貫通します。石のような硬い面に浅い角度で当たると、1 度だけ半分の威力で跳ね返ります。弾はブロックを壊しません。
  オペレーティング・シェルター・ブロックとそのガラスは、必ず弾を止めます。
- 操作(すべて「OUKA GUN MAX」の分類で変更できます。銃を持っているときだけ働きます):
  左クリック=撃つ / 右クリック=構える / R=リロード / F=見せる(銃を持っていないときは、いつもの持ち替え) /
  Z=パーツ画面 / N=弾の切り替え・エネルギーをためる / B=発射モード / K=スコープの倍率 / ダッシュ中にスニーク=スライディング
- ダッシュ中の銃も、構え直す時間のあとに撃てます。撃ち合いの判定はサーバーが行い、PvP はバニラの設定に従います。
- 銃の定義はデータパックで差し替えられます。/ouka reload(OP 用)で読み込み直します。
- 銃の撃ち方や動きは、反動・発射のバネ・リロードの動き・音まで、銃ごとに違います(音は次の「音」の節)。

■ 照準器と機能パーツ、Z 画面
- 照準器 4 種: OR-1「蛍」レフレックスサイト / OH-2「鏡」ホログラフィックサイト / OS-4「鳶」2〜4 倍可変スコープ /
  OT-3「陽炎」熱線サイト(生き物・溶岩・火・火の入った炉を 96 ブロック先まで映す。壁は透けません)。
  スコープの倍率は K キーで切り替えます。構えると周辺がぼけます。
- 機能パーツ 10 種: 銃口に MC-1「楔」コンペンセイター・MF-2「霞」フラッシュハイダー・MS-3「囁」亜音速サプレッサー、
  下部に UA-1「燕」アングルドグリップ・UV-2「柱」バーティカルグリップ、弾倉に MQ-1「疾風」早抜きマガジン・ME-2「重」拡張マガジン・
  MD-3「太鼓」ドラムマガジン、銃床とレーザーに SS-1「巌」安定ストック・SL-2「灯」レーザー照準モジュール。
  反動・音・弾倉の大きさ・構える速さなどが変わります。サプレッサーを付けると、本当に静かな発砲音に替わります。
- どの銃にどのパーツが付くかは、銃ごとに決まっています(拡張・ドラムのマガジンを付けられない銃もあります)。
- Z キーで、持っている銃の数値を「付ける前と後」で見られる画面が開きます。パーツは持ち物から使い、サバイバルでは外したパーツが戻ります。
  付けられるかどうかの判断はサーバーが行います。
- 既知の制限: ホログラムのパーツ画面と、パーツを付けるときの動きは、まだ入っていません。V1.4.0 の Z 画面は、装飾のない簡素な画面です。

■ 風力発電機: Type-W1「風神」
- 1 つのアイテムから、高さ 35 ブロックの風力発電機が自分で立ち上がります。ブレードは 3 枚で、風上へ向きを変えます。
- 定格出力は 1.0 MW。OUKA の電力網が求める分に合わせてブレードの角度を変えて発電し、求めがないときはブレードを寝かせて止まります。
  テスラパイロンが届かない所でも、止まります。
- Minecraft には風がないので、V1.4 は世界のシード・ディメンション・時刻・天候から風を計算します(晴れで平均 8.9 m/s、雨と雷で強まります)。
  風が 3 m/s を下回ると止まり、25 m/s を超えると安全のため止まります。
- 立てるには、24 ブロックの空きの柱と、ローターが回る空間が要ります。発電機どうしは 23 ブロック以上離してください。
- 既知の制限: 風力発電機が動くのは、天候のあるオーバーワールドだけです(天候のない所では「風がない」と表示され、回りません)。
- レシピは精密組立ラインにあります。

■ オペレーティング・シェルター: 7 色のガラスと新しい外見(V1.4)
- オペレーティング・シェルター・ガラス: クリア・オブシディアン / サクラ・ローズ / サイバー・シアン / ソーラー・アンバー /
  エメラルド・ジェイド / ヴォイド・アメジスト / アークティック・グレイズ の 7 色。
- 置くのも壊すのも OP だけです。どんな爆発(ほかの MOD のものも含む)も通さず、Mob も壊せません。光は色ガラスのように通し、弾は通しません。
- クリエイティブのタブには出ません。/give で渡してください(例: /give @s ouka:shelter_glass_sakura_rose 64)。
  ガラスをシェルター・ブロックのまわりに 8 枚並べるとクリア・オブシディアン 8 枚、それに染料 1 つで色つき 8 枚になります。
- オペレーティング・シェルター・ブロック本体は、ID・性質・レシピはそのままで、外見が変わりました(重い装甲板の見た目と、表示灯)。
  表示灯は見る人ごとに変わります。OP には緑の呼吸する光(3 秒周期)、OP でない人には赤い明滅(1 秒周期)です。
  誰が OP かは、ほかのプレイヤーには送られません。V1.3 で置いたシェルターにも働きます。

■ 物質トランシーバーと OKE
- 物質トランシーバーの描画が OKE に移りました。モデル・動き・テクスチャーは同じものを使い、サーバー側の働き(範囲・本数・転送量)は変わりません。
- 既知の制限: OKE に移ったのはトランシーバーだけです。ほかの機械は、まだ移っていません。

■ V1.3.1(修正版)の直し —— V1.4.0 にも入っています
- 回路投影ブループリントを使うと、OP でない人もオペレーティング・シェルター・ブロックを置けてしまっていました(V1.2.0 から)。
  ブループリントで置くときも、OP でない人のシェルターは置かれなくなりました(ほかのブロックは、これまでどおり建ちます)。
- 超次元量子圧縮サイロの組み方を、説明に書きました。入出力ポートは床の中心と、各側面の下から 2 段目の中心。耐熱ガラスは
  各側面の中央 3×3(下から 3〜5 段目)。内側の 3×3×5 は空けます。完成していないときの知らせには、合わない所をほかにも
  並べるようにしました(これまでは最初の 1 か所だけでした)。

■ V1.3「The Washitsu Architectural Masterpiece」—— 和室の 30 品と、工場の設備 10 種
- 和室の 30 品は、クリエイティブの新しいタブ「OUKA 和室」にまとまっています。工場の設備は OUKA のタブにあります。
- 電気で動く設備は、V1.2 の機械と同じく OUKA の電力網から電気を受けます。
- 新しい音 37 種は、すべて一から合成したものです。ブロックを壊す音や木を置く音などには、バニラの音も使います
  (くわしくは下の「音」の節)。
- レシピはすべて最初からレシピ本に出ます。

■ 和室: 床(畳・縁側・天井・壁)
- 本藺草仕立て畳: 1 枚で 2 マス。素手で右クリックすると、縁(へり)の柄が替わります(4 種)。
- **8 マス以上**つながった畳の部屋に立つと「スタミナ増強」が付き、満腹度の減りが半分になります。
- 縁なし市松畳: 隣の市松畳と直角の向きに敷かれ、並べると市松模様になります。しゃがんで素手で右クリックすると
  向きが替わります。畳の部屋のマスとしても数えられます。
- 桧磨き縁側床・杉目透かし天井板・聚楽土壁。天井板は固いブロックの下にだけ張れます。
  畳と縁側は、踏むとそれぞれの足音がします。

■ 和室: 障子と襖
- 本障子・金箔山水 襖: 2 マスの高さの引き戸です。素手の右クリックか、レッドストーンの信号で、
  ほぼ 1 ブロック滑って開け閉めします。開いていれば通り抜けられます。
- 同じ向きの戸の隣に置くと別の溝に入り、2 枚がすれ違って開きます(引き違い)。
- 襖は 4 枚並べると、1 枚の山水画になります。

■ 和室: 鴨居と、掛けるもの・吊るすもの
- 鴨居・長押フレーム: 欄間・透かし彫りを鴨居に使うと、鴨居の上に嵌まります。四季の掛け軸と二本掛け刀掛け台は
  (欄間を嵌めていない)長押の面に掛けられ、高級竹簾・藍染家紋暖簾・鉄器の風鈴は鴨居の下に吊るせます。
- 欄間・透かし彫り: しゃがんで使えば 1 枚で立ちます。光を通します。
  素手の右クリックで図柄が替わります(松に鶴・波千鳥)。
- 四曲金屏風: 置いた所を左下に、横 2 マス・高さ 2 マスに立ちます。
- 高級竹簾: 素手の右クリックで巻き上げます(全閉・半開・全開)。縦に 3 マスまで継いで 1 本の簾になります。
- 藍染家紋暖簾: 人がくぐると、布がめくれます。
- 簾・暖簾・風鈴は、鴨居か固いブロックの下に吊るします。支えが無くなると落ちます。

■ 和室: 調度
- 欅無垢座卓: 天板の 4 つの区画に、品を持って右クリックすると 1 つずつ飾れます(素手で取り戻します)。
  しゃがめばブロックを置けます。本格茶道 茶筅・抹茶碗セットと漆塗り 重箱は、座卓の上に置くと天板に載ります。
- 錦織の座布団と殿様脇息・座椅子: 素手で右クリックすると座り、しゃがむと立ちます。
  殿様脇息・座椅子は置いた人の方を向き、1 脚に 1 人です。
- 漆金具 桐箪笥: **27 枠**。ホッパーでもチェストと同じように出し入れでき、開けている間は引き出しが出ます。
- 本格茶道 茶筅・抹茶碗セット: 素手で右クリックすると茶を点て(2 秒)、もう一度右クリックすると飲みます。
  体力が全回復し、採掘速度上昇 II が **3 分**付きます。1 服は **5 分に 1 度**で、死んでもこの待ち時間は消えません。
- 漆塗り 重箱: バニラの食べ物だけが、3 段 × 3 つ入ります。壊しても中身は品の中に残り、置けば戻ります。
  火で焼け落ちません。

■ 和室: 床の間と坪庭
- 絞り丸太 床柱・四季の掛け軸: 掛け軸は 2 マスの高さで、壁か鴨居の長押に掛けます。
  絵はゲームの中の **8 日ごと**に季節で替わります(桜・滝・紅葉・雪嶺)。
- 竹筒生け花、銘木台座 水石、青磁香炉・伽羅香は、下に支えがあるときだけ立ちます。
  香炉からは一筋の香煙が昇ります。素手で消し、火打石と打ち金でまた火をつけられます。
- 二本掛け刀掛け台: 剣を持って右クリックすると掛けます(2 本まで)。素手で上の段から取ります。
  床に置くか、壁か鴨居の長押に掛けます。
- 角行灯・六角雪洞・御影石 雪見灯籠: 素手の右クリックで灯し、消します。雪洞は 2 マスの高さです。
  雪見灯籠の笠には、冬(32 日のうち 24〜31 日目)と、雪の降る寒い所では季節を問わず、雪が積もります。
- 庭園 鹿威し: 竹筒が水を溜めては傾き、**4.4 秒ごと**に受け石を打ちます。
- 鉄器の風鈴: 風で鳴ります。晴れのそよ風でも時おり、雨や雷雨ではよく鳴り、閉じた部屋の中では鳴りません。
- 榧の木碁盤・将棋盤: 素手で交点を右クリックすると、黒と白の碁石を交互に打ちます(9 路)。しゃがんで右クリックすると
  石を取ります。しゃがんで素手で盤の横を右クリックすると、碁盤と将棋盤が切り替わります(石は片付きます)。

■ 工場: 物流
- 超高加速インパルス・ホッパー: 上の器から吸い出し、上に落ちた品を吸い込み、吐き口の先のチェストやほかの MOD の管へ
  **1 tick に 64 個**(バニラのホッパーの 512 倍)押し出します。OUKA のコンベアへは 1 tick に 1 個です。
  しゃがんで素手で使うとフィルターの画面が開きます(5 マス。それぞれ完全一致・タグ一致・耐久値無視)。
  レッドストーンの信号で止まります。電気は要りません。
- OUKA式 空間転送トランシーバー [32m]: 器(チェスト・大釜・機械・サイロのポート)の面に置き、
  共振リンカーを送信機に、次に受信機に使って結びます。送信機 1 基から受信機 **4 基**まで、
  どの向きでも **32 ブロック**以内なら壁を越えて、1 tick に最大 **64 個**(画面で 1〜64)と **1 バケツ**を送ります。
  同じ次元の中だけです。電気は要りません。
- 量子サイロ直結I/Oバス: 量子圧縮サイロの部位の面に置き、後ろに器かコンベアを置きます。
  搬出では、選んだ品(**9 項目**まで)を、項目ごとの維持数をサイロに残して、後ろのチェストやほかの MOD の管へ
  **1 tick に 256 個**まで出します(OUKA のコンベアへは 1 tick に 1 個)。
  搬入では、後ろの器の品をすべてサイロへ入れます。電気は要りません。
- 超伝導加圧流体ポンプと超伝導加圧流体 導管: ポンプは、置くときに押した面の器から汲み、ほかの 5 つの面の
  導管へ送ります。**1 tick に 8 バケツ**を、導管の網のすべての行き先へ順番に、同じ tick のうちに配ります
  (水・溶岩・ほかの MOD の液体)。網は導管 **4,096 本**まで。ポンプは電気で動き(20 kW)、導管は電気を使いません。
  核分裂リアクターと培養槽は、導管から届く水でも動きます。
- 次元同期ポータブル端末: 組まれたサイロの制御盤に使って結び、何も無い所で使うと、そのサイロの画面が
  開きます(別の次元からでも)。持ち物(ホットバーとこの端末を除く)をまとめてサイロへ預けられます。
  結んだ端末を持っている人なら誰でも開けるので、鍵と同じように大切に持っていてください。

■ 工場: 生産
- 火山熱水式 造石・超粉砕機: 溶岩と水を 1 バケツずつ入れておけば、どちらも減らずに、丸石(**8 tick に 1 つ**)・
  砂利・砂・鉱砂のうち選んだものを作り続けます。鉱砂では砂 1 つと、ときどき鉄の粉(10 %)や金の粉(3 %)も出ます。
  電気で動き(60 kW)、作った品は前の器へ送ります。
- 自律共振式ブロック掘削機: 掘りたい岩の面に置き、道具の枠につるはしかシャベルを入れます。
  範囲は 1×1・3×3・**5×5**、深さは **16** まで。オーバークロックしなければ、その道具で人が掘るのと同じ時間で
  1 つずつ掘ります。シルクタッチ・幸運・効率強化・耐久力も同じように効き、道具の耐久値も 1 つ掘るごとに減ります。
  岩盤やチェストは掘りません。電気で動き(80 kW)、掘った品は後ろの器へ送ります。
- 分子超圧縮オートクラフター: 見本の 3×3 に品を並べると、作業台で同じ並びから作れる品を作ります
  (鉄のインゴット 9 つで鉄ブロック、など)。入口は見本の品だけを受けます。1 tick に 1 回
  (オーバークロックとタキオン・オーバークロック加速コアで **10 回**まで)作り、空のバケツなどの残り物も出します。
  電気で動き(40 kW)、作った品は前の器へ送ります。
- キネティック生体粉砕コレクター: 前の **5×3×5** の場で敵対モブをとらえ、(速めなければ)1 秒後に倒します。
  プレイヤーが倒したときの落とし物と経験値が出ます。ボス・名前の付いたモブ・プレイヤー・村人には触れません。
  場の中に落ちている品は、プレイヤーが落とした物も含めてすべて 27 枠へ吸い寄せます。
  電気で動き(100 kW)、品は後ろの器へ送ります。
- オーラカプセル: 粉砕コレクターのカプセルの枠に入れると、ためた経験値で満ちます
  (1 つに **1,395 ポイント**まで。レベル 0 からちょうどレベル 30 になる量です)。使うと、その経験値をすべて受け取ります。
- タキオン・オーバークロック加速コア: オーバークロックできる OUKA の機械の面に付けます
  (1 台に 1 つ。バニラのブロックには付きません)。素手の右クリックで段が替わり(200・400・600・800・1000 %)、
  しゃがんで素手で右クリックすれば段を選べます。万能工業ラチェットのオーバークロック(×1.00〜×2.50)と掛け算になり、
  **全体で ×10 まで**速めます。電気で動き(100 % を超える 100 % ごとに 40 kW)、
  機械の電力も速さの 2 乗で増えます。
- V1.3 の電気で動く設備(造石機・掘削機・クラフター・ポンプ・粉砕コレクター)も、
  万能工業ラチェットでオーバークロックできます。
- 回路投影ブループリントは、畳も屏風も、それぞれ 1 つとして写して建てます。

■ V1.2.0 からの直し
- OUKAビーコン・コア端末でスライダーを動かしたときの目盛りの音と、桜花の杖・弾幕の焦点の
  「色と弾道を選ぶ画面」で選んだときの音が、加わった V1.0.1 から V1.1.0・V1.2.0 まで、ずっと鳴っていませんでした。
  どちらも鳴るように直しました。

■ V1.2「The Heavy Industrial & Kinematics Epoch」—— 重工業の 20 品
- 機械はどれも OUKA の電力網で動きます。電力網はテスラパイロンがつなぎ、ケーブルは要りません。
- どの機械も、動きと音が働きぶりに合わせて変わります(音はすべて一から合成したもので、録音は使っていません)。
- レシピはすべて最初からレシピ本に出ます。

■ 電力(発電・送電・蓄電)
- 超高圧送電テスラパイロン(2 段): **64 ブロック以内**で届き合うパイロンが 1 つの網になり、網の近くの OUKA の機械へ
  無線で電気を配ります。電気が流れている間は、パイロンから機械へ青白い放電の弧が走ります。
- 超伝導磁気蓄電ブロック(SMES): **400 MJ**、充電・放電とも最大 **2 MW**、ロスはありません。面のホログラムに充電の割合。
- 重水減速型核分裂リアクター(5×5×5): ウラン・トリウムの燃料棒で最大 **2 MW**。炉心はチェレンコフ光で青く光ります。
  炉が 800 °C に届くと制御棒が落ちて止まり(スクラム)、冷えて冷却水が来ると動き出します。爆発はしません。
  冷却水は取水タービンから網を通って届きます。
- 太陽熱集光蓄熱タワー(3×3×8): 周り 16 ブロック以内のヘリオスタット(平面鏡、最大 32 枚)が日の光を集め、
  溶融塩に熱を蓄えます。タービンは最大 **400 kW** で、網の求めに合わせて出し、夜も蓄えから出し続けます。
  屋根の下の鏡は集めません。

■ 格納と物流
- 超次元量子圧縮サイロ(5×5×7): チタン外殻・耐熱ガラス・入出力ポートで外殻を組み、側面に制御盤を置くと完成します。
  **2,147,483,647 個**まで格納でき、画面で中身を一覧し、名前や「@MOD 名」で絞り込めます。
  ポート(底面と各側面)はホッパー・コンベア・ほかの MOD の管とそのままつながります。
  制御盤を壊すと中身の札を持った制御盤が落ち、別の場所で組み直せば同じ中身です。
- 高速超伝導リニアコンベア: **毎秒 20 個**を運びます。形(直線・カーブ・坂)は隣から自動で決まり、
  品は落ちず、詰まると並んで待ちます。運ぶ品はブロックに載ったまま見えます。
- リニアコンベアの分岐器: 左・前・右へ 1 つずつ順に分けます。詰まった出口は飛ばします。
- 波長分光式インテリジェント・ソーター: 通る品を、面ごとの決まり(品・タグ・MOD・データ成分・傷んでいるか)で 6 方向へ振り分けます。
- 自律型物流ドローンステーション(3×3): 行き先の港でドローン航路カードをしゃがんで使い、送る港で使うと、
  **Ouka-Cargo Drone** が荷を積んで港どうしを往復します。行き先では甲板(その港のドローンの場所)に降りず、港の脇で浮いたまま
  荷を渡します。区画が読み込まれていない間も、飛ぶ時間ぶん遅れて荷は届きます。

■ 精錬と加工
- 電弧重熱精錬炉(3×3×4): 鉱石を一度に **32 個**入れられ、かまどの **16 倍**の速さで精錬します。
  溶けた金属が樋を流れ、型に流し込まれるのが見えます。
- 超高圧油圧クラッシャー(2 段): 鉱石・原石 1 つから粉 2 つ(粉は精錬してインゴットに)、インゴットからは板を作ります。
  油圧でハンマーを持ち上げ、一気に叩きつけます。
- 高精度オートメーション組立ライン(1×4×2): 3 本のロボットアームとプレスが、電子回路・複合素材の板・機械の骨組みを
  組み立てます。溶接の火花が散ります。
- 分子遠心分離抽出機: 土・砂・砂利(と月のレゴリス)から、チタン・リチウム・石英・ヘリウム3 を微量に取り出します。
  ウランの粉からは確率で濃縮ウラン。

■ 採掘と収穫
- 地殻深層掘削クァーリー(4×4×6): 岩盤を壊さずに、深い鉱脈から鉱石・原油の缶を掘り続けます。
  **ジ・エンドでは掘りません**(ネザーではネザーの鉱石)。
- 超大型重水取水タービン(3×3×3): 水の上に置くと、下の水源から水を汲み上げます(深さ 2 の池で最大、**毎秒 200 バケツ**)。
  汲んだ水は網を通して、水を使う機械(核分裂リアクター・培養槽)へ届きます。
- 自律型重機製材ミル(3×3×2): 周り 8 ブロックの木を見つけて、上から切り倒し、板材にして、切り株に苗を植え直します。
- バイオリアクター培養槽(3×3×3): 有機物と水から、工業用プラスチック・潤滑油の缶・スタミナ増強剤を培養します。

■ 道具と装備
- 万能工業ラチェット: 機械を右クリックで前後を反転(中身と仕事はそのまま)。スニークして右クリックで、
  分岐器・ソーターの出口やコンベアの出口を開け閉めします。電力で動く加工機械では **オーバークロックの盤**が開き、
  速さを ×1.00〜×2.50 から選べます(速くするほど、品 1 つにかかる電力も増えます)。
- 携帯型熱分解カッター: OUKA の機械を 1 秒ねらい続けると、中身ごと持ち物へ解体します(1 滴もこぼしません)。
- 回路投影ブループリント: 向かい合う 2 つの角をスニークして使うと、その間(1 辺 16 マスまで)を写します。
  写したブループリントを持つと、建つ場所に**実物大の半透明のホログラム**が映り(置ける所は水色・品が足りない所は琥珀色・
  ふさがった所は赤)、使うと持ち物の品で建てます。
- 全天候型重工業防護外骨格(4 部位): 4 つそろえると、感電・熱・落下で傷つかず、溶岩の中を泳げ、採掘が 3 倍の速さになります。

■ V1.1.0 からの直し
- 桜花合金ブロックを掘っても何も落ちなかったのを直しました。
- シェルターの落とし物の表が古い形式だったのを直しました。

■ OUKA ビーコン
- 3×3×3 の構造物です。置いた場所が最下段の中央になります。
- 台座が要ります。ネザライト・ダイヤ・エメラルド・桜花合金のブロックを、
  8 段(3・3・5・5・7・7・9・9)で **328 個**。全部そろって初めて起動します。
- 起動すると、**半径 1,000 ブロック**の中にいるプレイヤー全員に効果を配ります。
  ビーコンのいる区画が読み込まれていなくても届きます。観戦者には配りません。
- 配る効果は 10 種類(移動速度・採掘速度・攻撃速度・攻撃力・跳躍・落下耐性・
  衝撃吸収・再生・満腹度・耐性と部分的な耐火・暗視)で、それぞれ **0.00 から 5.00 まで
  段階なし**で決められます。あわせて、エンチャントの金リンゴと同じ効果が常時つきます。
- ビーコンのどこかを右クリックすると、**すりガラスの端末**が開きます。スライダーを
  ドラッグ、マウスホイールで 0.1 刻み、Shift を押しながらで 0.01 刻み。
  ALL MAX / DEFENSIVE MATRIX / MINER'S PARADISE の 3 つの一括設定があります。
- 変更できるのは、置いた本人か OP だけです(8 ブロック以内)。ほかの人には読み取り専用で開きます。
- どこか 1 つでも壊すと 27 個すべてが外れ、設定を持ったビーコンが 1 つ落ちます。

■ サークル弾
- 桜花の杖(Ouka Caster)は 0.25 秒ごとに 1 発。直線・螺旋・追尾。
- 弾幕の焦点(Danmaku Focus)は 2 秒ごとに一斉射。収束(見ている点に 12 発)と
  周囲滞空シールド(8 発が回り、6 ブロック以内の敵へ飛ぶ)。
- どちらもスニーク+右クリックで、色と弾道を選ぶホログラムの画面が開きます。
- 色は 12 種類。それぞれ効果が違います(鈍化と魅了、画面の閃光、火柱、
  不死者へ倍の傷、引き寄せ、凍結、味方の回復と敵への毒、壁を貫く直線、
  索敵範囲を 8 割削る、2 つに分かれて追尾、3 回跳ね返る、ほか 11 色を巡る)。
- 着弾した場所から平らな輪が広がり、**通った敵を消滅させます**。ボスには最大体力の 2 割。
  プレイヤー・ペット・動物には当たりません。ブロックは壊れず、燃えません。
- 飛んでいる弾はその色の軌跡を残します。桜花桃だけは桜の花びらで、何秒も落ち続けます。

■ オペレーティング・シェルター・ブロック(V1.1 で追加)
- **OP 権限を持つ人だけ**が置けて、壊せます。ほかの人はどのゲームモードでも一切できません。
- どんな爆発も通りません。Mob も、ピストンも、クリエイティブの破壊も通しません。
  バニラが岩盤を入れている 11 のタグすべてに、同じように入れてあります。
- OP はサバイバルでも普通に掘れて回収できます(ダイヤ以上のつるはし)。
- OP でない人が触れると、面に六角のエネルギー格子が張り、金属の反発音と火花が返ります。
- 作り方: 黒曜石 4・ネザライトインゴット 4・桜花合金ブロック 1 で 2 個。

■ 音
- OUKA の音は **358 種**です(V1.6 で 73 種、V1.5 で 15 種、V1.4 で 177 種、V1.3 で 37 種ふえました)。新しい音も含めて、どれも **OUKA のために一から合成したもの**で、
  ほかのゲームの音も、素材集の音も、録音も使っていません。
- OUKA のブロック(V1.2 の機械も含みます)を壊す音・置く音・踏む音(畳と縁側の足音は OUKA の音です)と、
  和室の品のいくつかの音(木を置く音、抹茶を飲む音、火打石で灯す音など)、オーラカプセルを使ったときの音などには、
  バニラの音を使っています。
- **12 色は 12 半音。**サークル弾の音は色ごとに高さが違い、桜花桃から神光虹までが
  ちょうど 1 オクターブに収まります。**音を聞けば、どの色が飛んだか分かります。**
- 祭壇は、組み上がるとき・目を開けるとき・閉じるとき・解体されるときに鳴り、
  起動しているあいだは低い唸りを出します。
- 端末を開いた音や、変更が断られた音は、**その本人にだけ**聞こえます。
- 銃の発砲音は 4 層です(機構・砲声・残響・衝撃波の「ピシッ」)。銃ごとに機構と砲声の音が違い、残響は
  開けた場所・谷・屋内のどれかを周りから見て選びます。残響は連射のあいだ毎発は鳴らさず、音のチャンネルを使い切らないようにしています。
- 風力発電機は、うなり・ブレードが風を切る音・起動・ブレーキ・立ち上がりの音を持ちます。
- 字幕(「サブタイトルを表示」)に対応しています。

■ 道具とレシピ
- 桜花合金インゴット / 桜花合金ブロック(相互に変換できます)
- OUKA ビーコン
- 桜花の杖(Ouka Caster)
- 弾幕の焦点(Danmaku Focus)
- V1.2 の機械・道具・装備・素材(上の V1.2 の節)
- V1.3 の和室の 30 品と工場の設備 10 種、それに共振リンカー・オーラカプセル・導管(上の V1.3 の節)
- V1.4 の銃 15 丁・弾 6 種・パーツ 14 種・風力発電機・シェルターガラス 7 色(上の V1.4 の節)
- V1.6 の和室の品 50 種と溝つき桧の敷居、重工業の機械 30 種と材料 32 種(上の V1.6 の節)。材料は機械の工程で作ります。
- V1.5 の鋼鉄の守護騎士の彫像・宝物庫の強化扉と総鍵・守護騎士の大断頭斧・重鉄の防壁インゴットと防具 4 点・
  守護騎士のスポーンエッグ(上の V1.5 の節。扉・総鍵・大断頭斧・インゴットに作り方はありません)
  レシピはゲーム内のレシピ本で見られます。

■ マルチプレイ
- サーバーとクライアントの両方に入れてください。
- 端末の操作はすべてサーバー側で確かめています。範囲外の値や、権限のない変更は通りません。
- オーバークロックの盤も同じです。ラチェットを持ち、8 ブロック以内にいて、そこで建築できる人だけが変えられ、
  ×1.00〜×2.50 の外の値は通りません。
- V1.3 の設備の画面(トランシーバー・I/O バス・掘削機・造石機・クラフター・加速コア・ホッパーのフィルター)も同じです。
  8 ブロック以内にいて、そこで建築できる人だけが変えられます。
- 銃の発射・当たり判定・パーツの取り付けは、すべてサーバーが決めます。クライアントは、感触のために同じ規則で先読みするだけです。
- 守護騎士の攻撃・受け流し・衝撃波の当たり判定は、すべてサーバーが決めます。
- 組立ラインの製品の選択は、サーバーが確かめます。8 ブロック以内にいて、そこで建築できる人だけが変えられ、
  実在する組立レシピだけを受け付けます。
- /ouka reload と /ouka mount は OP(ゲームマスター権限)用です。

■ ライセンス
- OUKA: MIT(LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT(LICENSES/GeckoLib_MIT.txt)。改変せずそのまま同梱しています。

------------------------------------------------------------------

[English]

■ What you need
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- Java 25

■ Installing (on both the client and the server)
1. Put the two jars from this zip's mods/ folder into your Minecraft mods folder.
   - ouka-1.7.0+mc26.3.jar
   - geckolib-fabric-26.3-5.5.6.jar
2. Put Fabric API in the same folder (the version above or newer).
3. To play on a server, install the same two jars and Fabric API on the server as well.

■ Please note
- GeckoLib is bundled in this zip. If another mod already installs GeckoLib, keep only
  one copy — two will stop the game from starting.
- When updating from an earlier version, remove the old OUKA jar (ouka-1.6.2.2+mc26.3.jar, ouka-1.6.2+mc26.3.jar, ouka-1.6.1+mc26.3.jar, ouka-1.6.0.1+mc26.3.jar, ouka-1.6.0+mc26.3.jar, ouka-1.5.0+mc26.3.jar, ouka-1.4.0+mc26.3.jar,
  ouka-1.3.1+mc26.3.jar, ouka-1.3.0+mc26.3.jar, ouka-1.2.0+mc26.3.jar, ouka-1.1.0+mc26.3.jar,
  ouka-1.0.1+mc26.3.jar and so on) from the mods folder. Two OUKA jars will stop the game from starting.
- Worlds from V1.4 and V1.5 open in V1.6.0. An assembly line placed before V1.5.0 starts with nothing
  selected and waits until you choose a product (see "Automated Precision Assembly Line" below).
- There is no config file, and no new key binding or command in V1.6.0. From V1.4 there are two
  operator commands (/ouka reload and /ouka mount).
- V1.6.0 stands alone: there is no compatibility with other mods' weapons.
- This version is for Minecraft 26.3 only.
- Going back to V1.5.0 after playing V1.6.0 would delete V1.6.0's new blocks and items (the Japanese-room pieces, the
  heavy-industry machines and their materials) from the world (normal mod behaviour). That is not supported.
- V1.6.1 adds new key bindings (defaults J, U and I) and the operator command /ouka sorcery (see the V1.6.1 section below).
- V1.6.2 adds 6 new items and 3 new blocks: the Ryusei superconducting maglev train (see the V1.6.2 section below).
- V1.6.2.2 adds a fuel slot to the Catalytic Smelting Furnace (raw tungsten ore and ancient debris, burning argon),
  a 18-slot material buffer to the Precision Assembly Line, and a Hand-Crank Generator for the first power in pure survival
  (see the V1.6.2.2 section below). All figures are provisional.
- V1.6.2.1 is a wording fix for the Ryusei maglev train (see the V1.6.2.1 section below).
- V1.7.0 adds Limitless: Gojo's and Sukuna's techniques, the domains, Kamutoke and Hiten. It adds five key bindings
  (defaults R, Z, V, X and C; see the V1.7.0 section below).

■ V1.7.0 — Limitless
- Play Gojo's and Sukuna's techniques. Switch abilities with R, use them with Z and V, reset the selection with X and open
  the technique menu with C. The keys can be changed under Limitless in Controls.
- Gojo: Infinity, Lapse Blue, Reversal Red, Hollow Purple and the Infinite Void domain (Domain Expansion).
- Sukuna: Dismantle, Cleave, Open and the Malevolent Shrine domain. The Kamutoke weapon calls down lightning.
- Items: Kamutoke, Hiten, the Blindfold, the Character Guide and six spawn eggs. Block: the Domain Barrier (unbreakable
  and blast-proof). The Blindfold is made from three black wool. The Character Guide is given once when you first join
  and explains each technique.
- The names are the original English names.
- Known issue: with the graphics option Improved Transparency turned on (it is off by default), the Hollow Purple sphere is
  drawn in front of water instead of behind it. This will be fixed in 1.7.1. With the option off it is drawn correctly.
- Going back to an earlier version after playing 1.7.0 removes the Domain Barrier and every Limitless item from the world
  (normal mod behaviour).

■ V1.6.2.2 — furnace fuel, assembly-line material buffer, hand-crank generator (provisional figures)
- Catalytic Smelting Furnace: raw tungsten ore goes straight in and comes out as 2 tungsten ingots for one argon canister,
  160 ticks (provisional). Ancient debris makes one netherite scrap (as vanilla does) for one argon canister, 160 ticks (provisional).
  Argon canisters go in the fuel slot on the right of the furnace; the fuel slot takes argon only. Hoppers put argon in the fuel
  slot and the materials in the input. Without argon the furnace says it is waiting for fuel and takes nothing.
- Precision Assembly Line: a material buffer of 18 slots (provisional) takes parts of any assembly recipe, selected or not, placed by hand in its screen slots, so you can pre-load and pick a recipe later (hoppers and conveyors still feed the intake as before).
  A craft takes from the intake when it is complete there, otherwise from the buffer, taking exactly the recipe's counts and nothing
  when short. The recipe list shows a green edge on recipes the buffer can craft now (live: it updates while the screen is open).
- Hand-Crank Generator (new block, provisional): right-click (hold to keep turning). One click gives 4,000 J per tick for 6 ticks
  (24,000 J) into the power grid through a tesla pylon; unused power is lost. Turning tires you a little.
  Vanilla materials only (sticks, iron ingots, a piston). First power: hand-crank -> tesla pylon (its alloy ingot is made from
  vanilla items) -> hydraulic crusher.
- All figures are provisional. The hunger cost is not checked by a test.

■ V1.6.2.1 — wording fixes for the Ryusei maglev train
- The aura effect icon stays in the effect list. Hovering over it shows each aura channel that is active, with its level and
  what it does. The aura table at the top right of the screen is no longer drawn. The aura effects work as before.
- The Ryusei item descriptions now include a short operation summary: trains run automatically (ATO) between stations;
  an empty hand on the Dispatch Console starts or stops the service; sit in the head car or an observation car seat to see the gauges.
- Using a car item on a block says that cars cannot be placed on the guideway. Using the Consist Card on a block other than
  the Dispatch Console says to use it on the console.
- When the next station is too close to a line end for the train to fit, the riders are told why. (Before, the doors closed and
  reopened with no message.) Placing a Stop Coil, using one empty-handed, and using a Consist Card on the console also say the reason.

■ V1.6.2 — the Ryusei superconducting maglev train
- Six new items and three new blocks are added. The train is made of four cars: the head car, the passenger car,
  the observation car and the power car. The items are the Ryusei Survey Transit, the four cars and the Consist Card.
  The blocks are the Guideway Node, the Stop Coil and the Dispatch Console.
- How to start:
  1. Use the Ryusei Survey Transit on one Guideway Node, then on the next, to link them. Each link must keep to the
     limits on node spacing, the tightest curve and the slope. If a link is refused, the transit says why.
     After each link it reports the line's length, its tightest curve and the speed the line allows.
  2. Place a Stop Coil near a linked guideway to make a station. The train stops with its middle at the coil,
     and the doors open on the coil's side.
  3. Place a Dispatch Console near a Stop Coil. Use a Consist Card on it to put the train at that station.
     Used empty-handed, it starts or stops the shuttle between stations. Sneak and use it empty-handed to take a
     waiting, empty train back to its card.
  4. Sit in the head car's cab seat to read the speed, the inverter frequency and the line voltage.
- Boarding: the doors open only while the train is stopped at its station mark. The doors stay locked while the train
  moves. A seat is used to sit down, and sneaking stands you up. You can walk the aisle while the train moves.
- If something stands in the guideway, the train stops short of it and waits. The train does not break blocks.
- There are no power blocks or power network yet. The voltage and frequency on the cab readout are for show only.
- Going back to V1.6.1 after playing V1.6.2 would delete the Ryusei items and blocks from the world. That is not supported.

■ V1.6.1 — the Spirit Vein Engine (sorcery)
- Four new items and one new block, the Sigil Mark, are added. Each item is made on the Automated Precision Assembly Line
  by choosing it as the product (they are not on the 3 x 3 crafting table). The four items are the Silver Rite Dagger,
  the Sigil Focus, the Sight Lens and the Ward Chalk. Ward Chalk draws a Sigil Mark on the top face of a block.
- How to start:
  1. Sneak and use the Silver Rite Dagger to perform the Blood Rite. It costs a little health and opens your spirit vein.
     A rite is refused when your health is low (it never kills you). In creative mode the rite costs no health.
  2. When your vein capacity has grown, perform the rite again to go up a tier. A tier never rises on its own.
  3. Hold a Sigil Focus in your main hand. Hold the Phantom Blade Rain key (default J) to rain blades. Press the
     Vein Status key (default I) to read your spirit, tier and growth.
  4. Hold use with a Sight Lens to look through it. Press the Spirit Sight key (default U) to switch the sight: Stillness
     Sight from tier 3, Keen Sight from tier 4. The lens works from either hand.
  5. Ward Chalk is used from tier 2. Draw a Sigil Mark on the top face of a block, then pour spirit into it with a Sigil Focus.
- Spirit: the vein regains spirit over time, and its capacity grows when you spend your spirit from nearly full to nearly
  empty by casting. The rates and growth are set in the data files (data/ouka/sorcery) and can be changed there.
- Phantom Blade Rain: blades fly where you look, plant themselves, and burst a moment later. Blades and bursts never break blocks.
- Sigil Mark: with an empty hand it switches Alarm, Siphon and Bulwark; with Ward Chalk it changes the reach. With a
  Silver Rite Dagger it clears the list of trusted players. Anyone can break a mark (one chalk drops).
- How many wards: each person has a limit on wards, which rises with the tier. A ward's tank is filled by pouring spirit
  with a Sigil Focus; when the tank runs dry, the ward falls.
- What the wards do and do not do:
  - Alarm Ward: tells you when a player who is not trusted, or a hostile creature, comes inside.
  - Siphon Ward: drains health from players and hostile creatures that are not trusted, and turns it into spirit. A
    player is never drained to death.
  - Bulwark Ward: stops arrows and other projectiles, and explosion damage, coming from outside into the ward. Melee,
    magic and falls are not stopped, and the push from an explosion is not stopped.
  - A ward never traps anyone, and it protects no blocks.
  - Trust: while the owner holds a Sigil Focus in the main hand nearby, another player who uses an empty hand on the mark
    is trusted (up to a set number of players).
- Spirit Sight:
  - Stillness Sight: holds a few creatures you look at, within a short range (their speed is set to zero). It does not hold
    bosses. A player is held only where PvP is allowed, briefly, and then is immune for a while. Floating targets sink
    slowly (a known limit).
  - Keen Sight: a hit on a weak point (the head by default) with an OUKA gun or a phantom blade does much more damage. A
    boss takes only a limited share of its maximum health from one hit. A player takes no extra damage.
  - With a lens held, Spirit Sight marks hostile creatures and bosses through walls (not players). It uses spirit while open.
- The keys J, U and I are the defaults and can be changed under the "OUKA Spirit Vein" controls category.
- Worlds from V1.6.0.1 open as they are. Going back to V1.6.0.1 after playing V1.6.1 would delete the Sigil Mark and the four new
  items from the world (normal mod behaviour). That is not supported.
■ V1.6.0.1 — balance changes and one addition (12 October 2026)
- The Volcanic-Hydraulic Cobblestone Synthesizer can now make clay. "Clay" joins the list of products on its screen
  (one every 1.6 seconds; as with cobblestone, gravel, sand and ore sand, the lava and water are not used up).
- Every machine that runs on power now draws twice as much (the V1.2 and V1.3 machines, the Tachyon Accelerator Core
  and the V1.6.0 heavy-industry machines). Generation and storage ratings are unchanged (wind turbine, solar tower,
  fission core, artificial sun, SMES, flywheel, molten salt). A factory built before this update runs half as many
  machines on the same supply; a machine that is short of power stops and waits (nothing breaks).
- The OUKA Beacon's effects now go up to 5.00 instead of 20.00 (a quarter). A beacon already set above 5.00 reads as
  5.00 when it loads. Its 1,000-block radius and its 328-block pedestal are unchanged.
- The OUKA Beacon costs half as much to craft: 2 beacons, 2 Ouka alloy blocks and 1 nether star (it was 4, 4 and 1).
  On the crafting table: an alloy block above and below, a beacon left and right, the nether star in the middle.
- Worlds from V1.6.0 open as they are. There is no new block or item.

■ V1.6.0 "The Grand Synthesis" — the washitsu gap fix and fifty-one Japanese-room pieces, thirty heavy-industry machines and thirty-two materials
- Washitsu: a fix that closes the gap between neighbouring shoji and fusuma, a new Grooved Hinoki Sill, and fifty new
  Japanese-room furnishings (fifty-one blocks with the sill).
- Heavy industry: thirty machines and thirty-two new materials. There are four utilities (vacuum, air, coolant and clean);
  some machines take the ones they need from a machine that touches them.
- The release adds 81 new blocks, 113 new items (the block items and the materials) and 73 new sound events (see "Sound" below).
- There is no new key binding, no new command and no config file.

■ Washitsu: the gap fix and the Grooved Hinoki Sill (V1.6.0)
- Neighbouring shoji and fusuma had a gap that let light through at some angles. In V1.6.0 every back-rail panel
  has a closing piece at each end, which fills that gap. Collision, rails, recipes and the sliding motion are unchanged.
- The Shikii Grooved Hinoki Sill is a new block: the sill that goes under a shoji or fusuma.
- The closing piece is drawn only: the crosshair and bullets still pass through the 3-pixel gap between the rails, as before.
  Slightly translucent washi paper, and a view through lattices and glass, are by design. How open doors look is not part of this fix.

■ Washitsu: fifty furnishings (V1.6.0)
- Doors, windows and screens (11): Diamond-Lattice Shoji, Yukimi Shoji (the glass pane slides up), Drum-Faced Fusuma,
  Misu Silk-Bordered Blind, Thousand-Slat Lattice Door, Hemp-Leaf Kumiko Shoji, Amado Storm Shutter, Lattice Window,
  Round Window Frame, Tsuitate Standing Partition and Two-Fold Pillow Screen.
- Tokonoma and the room (12): Karin Single-Plank Stand, Staggered Tokonoma Shelves, Raden-Inlay Writing Desk, Shoin Bay Desk,
  Pure-Gold Tea Kettle, Bronze Hanging Lantern, Iko Garment Rack, Kendai Book Lectern, Ozen Meal Tray, Tokkuri and Sake Cups,
  Alcove Floor Step and Stacked Futon.
- Irori and the kitchen (3): Irori Sunken Hearth, Jizai Hook and Iron Pot, Hibachi Brazier.
- Garden (16): Raked White Gravel, Gravel Border Curb, Standing-Stone Triad, Tall Standing Stone, Stepping Stone,
  Flagstone Paving, Moss Mound, Close-Set Bamboo Fence, Four-Eye Bamboo Fence, Brushwood Garden Gate, Tsukubai Basin,
  Kakei Bamboo Spout, Suikinkutsu, Izutsu Well Curb with Bucket, Vermilion Bridge Railing and Bonsai on Stand.
- Light, sound and season (8): Ground Stone Lantern, Chochin Paper Lantern, Glass Wind Bell, Taiko Drum on Stand,
  Koto 13-String Zither, Kadomatsu New-Year Pine, Daruma Doll and Carp Streamer Pole.
- Seven pieces have sounds of their own (ten sound events): the taiko, the koto, the suikinkutsu, the glass wind bell, the raked
  gravel, the Yukimi Shoji and the Amado Storm Shutter. All 73 new sound events are counted in "Sound" below.

■ Heavy industry: thirty machines and thirty-two materials (V1.6.0)
- There are thirty machines. Their models are drawn with GeckoLib.
- There are four utilities: vacuum, air, coolant and clean. Some machines wait until the provider they need (the Vacuum Pump,
  Gas Compressor, Coolant Circulation Pump or Cleanroom Fan-Filter Unit) touches them. Other machines need no utility.
- The Artificial Sun Core is 7 x 7 x 7 blocks. Its nameplate output is 1.00 GW, which is 50,000,000 J per tick.
- The Gas-Centrifuge Tower turns rare-gas canisters into argon canisters and, from its own process, Helium-3 canisters.
- Materials are made in machines (Raw Tungsten alone comes from the Sub-Crustal Thermal Bore): tungsten (raw, dust, ingot and plate), pure titanium ingot, titanium plate, five ultrafine
  powders, graphene sheet, carbon plate, tungsten carbide billet and plate, six canisters (liquid oxygen, rare gas, argon,
  synthesis gas, kerosene and gasoline), deuterium cell, refractory brick, catalyst pellet, slag, nitrate salt, silicon
  wafer, micro circuit board, quantum chip, precision module, superconducting coil and electrolytic copper plate.
- Each machine is made on the assembly line from its own recipe (thirty recipes). None of them is a 3 x 3 crafting recipe.

■ V1.5.0 "The Wrought Iron Sovereign Update" — the Wrought Iron Sovereign, the Treasury Door, the Sovereign Battleaxe, Wrought Plate armour and a product choice for the assembly line
- A new boss, the Wrought Iron Sovereign, and its statue, the Wrought Iron Statue.
- The Treasury Door and the Treasury Master Key; the Sovereign Battleaxe; the Wrought Plate Ingot and four pieces of Wrought Plate armour.
- The Automated Precision Assembly Line now builds only the product you choose, on a new selection screen (a fix).
- Ten new items, two new blocks and fifteen new sound events (see "Sound" below).

■ The Wrought Iron Sovereign (boss)
- It is 3.8 blocks tall with 300 health (150 hearts). It does not spawn naturally: use its spawn egg or /summon.
- It starts asleep and stands as still as a statue. A living survival or adventure player who comes within
  8 blocks of it, or who attacks it, wakes it. Once awake it stays awake until it is defeated. Its health bar
  appears only after it wakes, for players within 64 blocks.
- While awake it turns every attack aside: no damage, and the attack does not count as a hit. This applies
  from every direction, the back included.
  - For about 3.5 seconds after its overhead blow, while the axe is stuck in the ground, its back opens.
    During that time attacks from the front and sides are still turned aside.
  - Only attacks from the rear 145-degree arc (level with the ground) get through, and they deal five times the damage.
  - At most 100 damage gets through in one opening, and the opening ends when that is reached. So at least
    three openings are needed to defeat it.
  - The Susanoo round (Type-50) and the circle projectiles' shock wave (the ring that spreads where a circle stops) deal 60 from behind during an opening. They are not multiplied.
- Its attacks (damage depends on difficulty and armour):
  - Overhead blow: it brings the axe down in front of it, dealing 14 damage to living things nearby and throwing
    them outwards. A short-lived crack appears on the ground; no block is changed.
  - Pull-out sweep: after the axe is freed, 10 damage to living things within 4.5 blocks.
  - Shield bash: 8 damage to living things in front of it, within 3.2 blocks.
- Defeating it always drops 1 Treasury Master Key, 1 Sovereign Battleaxe and 8 Wrought Plate Ingots, plus 400 experience.

■ Wrought Iron Statue
- A 3 x 3 x 4 block figure of the sleeping Sovereign. It does not move and never wakes.
- The whole 3 x 3 x 4 space around it must be clear when it is placed. Breaking any part removes the
  whole figure and drops one statue.
- Recipe, on the Automated Precision Assembly Line: 2 Machine Frame, 12 Composite Plate, 24 Iron Plate and
  4 Ouka Alloy Plate make 1 statue. It does not come from the boss.

■ Treasury Door and Treasury Master Key
- The door is two blocks tall. Right-click it with the key in either hand to open it, and again to close it.
  The key is never used up and has no durability.
- Without the key the door stays shut and says: "It is locked. Only a Treasury Master Key opens it."
- Any Treasury Master Key opens any Treasury Door. Doors and keys are not paired.
- In survival the door cannot be broken, and explosions, the Wither and the Ender Dragon do not break it.
  Creative players can break it and get nothing back.
- Only operators can place a Treasury Door; anyone else is told so and keeps the item. Neither the door nor the
  key has a recipe: operators hand the door out, and the key drops only from the boss.
- Redstone does not open it.

■ Sovereign Battleaxe
- A melee weapon: attack damage 13, durability 1,800. Repair it on an anvil with Wrought Plate Ingots.
  It has no recipe and drops only from the boss.
- Hold the use button for 1.2 seconds and release it to send a shock wave: a fan 6 blocks long and 80 degrees
  wide, reaching 3 blocks up and down. It deals 14 damage, stops whatever it hits from moving for 2 seconds, and
  pushes it away. Releasing before 1.2 seconds does nothing.
- The cooldown is 8 seconds, and each shock wave costs one durability. It breaks no block and changes no ground.
- It does not hit its user or the user's tamed animals.
- Against the Wrought Iron Sovereign, the shock wave is turned aside from the front and sides, deals 70 from
  behind during an opening, and never stuns the boss.

■ Wrought Plate Ingot and Wrought Plate armour
- The Wrought Plate Ingot drops only from the boss, 8 per defeat. It is fire-resistant. It is used for the armour
  recipes and for anvil repairs of the armour and the battleaxe.
- Armour points: helmet 3, chestplate 8, leggings 6, boots 3 (20 in all). Each piece gives 0.25 knockback resistance.
  Wearing all four pieces together gives full knockback resistance: no knockback, though damage still applies.
- Recipes on the assembly line, one piece at a time:
  - Helmet: 4 Wrought Plate Ingot, 2 Composite Plate, 1 Electronic Circuit
  - Chestplate: 6 Wrought Plate Ingot, 1 Machine Frame, 4 Composite Plate, 1 Electronic Circuit
  - Leggings: 5 Wrought Plate Ingot, 3 Composite Plate, 2 Industrial Plastic
  - Boots: 3 Wrought Plate Ingot, 2 Composite Plate, 1 Industrial Plastic, 2 Iron Plate
- A full set needs 18 ingots, so the boss must be defeated three times (24 ingots).

■ Automated Precision Assembly Line: it builds only what you choose
- Up to V1.4.0 the line had no way to choose a product. It built the first recipe, in name order, whose parts
  were all in its intake. So 16 of the 42 assembly recipes in V1.4.0 came out as a different item even when
  you put in exactly their parts: eleven guns, and five parts, tools and armour pieces.
- A new selection screen lists every assembly recipe. Open it by using the line with an empty hand when there is
  nothing to collect, or by holding an item the line does not accept. Click a product to preview it, then press
  "Build this". Nothing changes until you press it.
- With a product chosen, the line accepts only that product's parts, whether they come by hand, hopper, conveyor
  or pipe. Changing the choice returns the parts the new product does not use to the player who pressed the button.
  "Clear the choice" returns everything in the intake.
- The choice is saved with the line and survives restarts and chunk reloads. A broken line keeps its choice on the item.
- If a data pack removes the chosen recipe, the line stops, reports that, and keeps its parts.
- The aiming outline now follows the drawn shape of the machine. The machine's size and collision did not change.
- Migration: a line placed in V1.4 loads with nothing selected and waits. Nothing is lost: its parts, a finished item,
  a job already running and stored power are all kept. But a waiting line accepts no parts, so hoppers and conveyors
  feeding it back up, and factories stand still until each line is opened once and given a product.

■ V1.4.0 "The Kinetic Overdrive" — fifteen guns, fourteen parts, a wind turbine and coloured shelter glass
- A new animation runtime, OKE: it builds motion from rigs (bone skeletons) and springs. It drives the guns and the wind turbine, and
  the Matter Transceiver is now drawn with it too. GeckoLib is still required (the other machines are still drawn with it).
- Forty-three new items: 15 guns, 6 kinds of ammunition, 14 parts, 1 wind turbine and 7 shelter glasses. The guns and parts are in the OUKA creative tab.
- 177 new sounds (see "Sound" below).
- The V1.3.1 fixes are included.

■ Guns (OUKA GUN MAX): fifteen
- Guns are made on the Precision Assembly Line. There are six kinds of ammunition, all made at a crafting table (light, heavy, energy,
  shotgun, sniper and mythic rounds). Reloading uses rounds from your inventory; in Creative they are never used up.
- The fifteen (names as shown in game):
  01 Type-01 "Kusanagi" Carbine / 02 Type-47 "Raijin" Heavy Rifle / 03 Type-99 "Hayabusa" High-RPM SMG / 04 Type-09 "Raikiri" Plasma Energy SMG /
  05 Type-88 "Muramasa" Dual-Caliber SMG / 06 Type-12 "Ronin" Lever Shotgun / 07 Type-08 "Tatsumaki" Auto-Drum Shotgun /
  08 Type-04 "Onibi" Line-Spread Shotgun / 09 Type-44 "Kojiro" Heavy Hand Cannon / 10 Type-77 "Gekkou" Amped Bolt Sniper /
  11 Type-50 "Susanoo" Anti-Materiel Cannon / 12 Type-55 "Fudo" Heavy LMG / 13 Type-24 "Kagutsuchi" Accelerating LMG /
  14 Type-03 "Mitsuboshi" Triple-Core Marksman / 15 Type-20 "Suzumebachi" Tactical Rapid Pistol (each name begins with "OUKA")
- Each gun has its own trick. The Raikiri builds heat as it fires and vents it on reload. The Muramasa switches between light and heavy rounds with N.
  The Gekkou can be energised with N, and its next shot does double damage. The Kagutsuchi spools up from 330 to 900 rounds a minute as you hold the trigger.
  The Fudo settles down the longer it fires. The Onibi's pellets set a target alight (blocks do not burn). The Mitsuboshi fires three parallel cores.
  The Susanoo kills any non-boss living thing in one shot (a boss loses 20% of its maximum health), with a range of 1,024 blocks.
- Shots land instantly out to 50 blocks and, beyond that, fly as a round that falls and slows. Wooden doors, glass, iron bars and the room's shoji and fusuma
  are passed through at reduced power. A shallow hit on a hard surface such as stone ricochets once, at half damage. Rounds never break blocks.
  The Operating Shelter Block and its glass always stop a round.
- Controls (all rebindable under "OUKA GUN MAX", and active only while you hold a gun):
  Left click = fire / Right click = aim / R = reload / F = inspect (with no gun in hand it swaps hands as usual) /
  Z = parts screen / N = switch ammunition or energise / B = fire mode / K = scope magnification / sprint, then sneak = slide
- A gun carried at a sprint can fire after a short raise time. The server decides every shot and hit; PvP follows vanilla rules.
- Gun definitions can be replaced by a data pack; /ouka reload (operators) reloads them.
- Recoil, the firing spring, reload motion and sound are different for each gun (sound: see "Sound" below).

■ Sights, functional parts and the Z screen
- Four sights: OR-1 "Hotaru" Reflex Sight / OH-2 "Kagami" Holographic Sight / OS-4 "Tobi" 2-4x Variable Scope /
  OT-3 "Kagerou" Thermal Sight (shows living things, lava, fire and lit furnaces up to 96 blocks away; it does not see through walls).
  Scope magnification is stepped with K. Aiming blurs the periphery.
- Ten functional parts: on the muzzle, the MC-1 "Kusabi" Compensator, MF-2 "Kasumi" Flash Hider and MS-3 "Sasayaki" Subsonic Suppressor;
  under the barrel, the UA-1 "Tsubame" Angled Grip and UV-2 "Hashira" Vertical Grip; for the magazine, the MQ-1 "Hayate" Fast-Draw Magazine,
  ME-2 "Kasane" Extended Magazine and MD-3 "Taiko" Drum Magazine; and for the stock and laser, the SS-1 "Iwao" Stability Stock and SL-2 "Akari" Laser Aiming Module.
  They change recoil, sound, magazine size, aim time and more; the suppressor really does swap in a quieter shot.
- Which parts fit which gun is set per gun (some guns refuse the extended and drum magazines).
- Z opens a screen showing the held gun's figures before and after a fit. Parts come from your inventory, and in survival the part you replace comes back.
  The server decides whether a part fits.
- Known limits: the holographic parts screen and the mounting animation are not in yet. The V1.4.0 Z screen is a plain one.

■ The Type-W1 "Fujin" Wind Turbine
- From a single item, a 35-block wind turbine raises itself. It has three blades and turns into the wind.
- Its rated output is 1.0 MW. It pitches its blades to match what the OUKA power grid asks for, and feathers them to stop when nothing is asked,
  or when no Tesla pylon is in reach.
- Minecraft has no wind, so V1.4 works one out from the world seed, dimension, game time and weather (a clear-weather mean of 8.9 m/s; rain and thunder add to it).
  Below 3 m/s it stops; above 25 m/s it stops for safety.
- It needs a clear 24-block column and open air for the rotor, and two turbines must stand at least 23 blocks apart.
- Known limit: the wind turbine runs only in the Overworld, where there is weather (elsewhere it says there is no wind and does not turn).
- The recipe is on the Precision Assembly Line.

■ The Operating Shelter: seven glass colours and a new look (V1.4)
- Operating Shelter glass, in seven colours: Clear Obsidian / Sakura Rose / Cyber Cyan / Solar Amber / Emerald Jade / Void Amethyst / Arctic Glaze.
- Only operators can place or break it. It withstands all explosions (including other mods'), and mobs cannot break it. Light passes through like stained glass; bullets do not.
- It is not in the creative tab: hand it out with /give (for example /give @s ouka:shelter_glass_sakura_rose 64). Eight panes around a shelter block
  make 8 Clear Obsidian, and 8 panes plus one dye make 8 of that colour.
- The Operating Shelter Block itself keeps its ID, properties and recipe; only its look changes (a heavier armour-plate face and an indicator lamp).
  The lamp differs for each viewer: an operator sees a green breathing light (3-second cycle), anyone else a red pulse (1-second cycle).
  Who is an operator is never sent to other players. It works on shelters already placed in V1.3 worlds.

■ The Matter Transceiver and OKE
- The Matter Transceiver is now drawn by OKE. Its model, animations and textures are the same files, and what it does on the server (range, receivers, throughput) is unchanged.
- Known limit: the transceiver is the only machine on OKE so far. The others have not moved over yet.

■ V1.3.1 (a fix release) — fixes since V1.3.0, also in V1.4.0
- The Holographic Circuit Blueprint let players who are not operators place the Operating Shelter Block (since V1.2.0).
  A blueprint now leaves the shelter out for them; every other block is built as before.
- The Quantum-Compression Vault now explains its layout: I/O ports go in the centre of the floor and the
  centre of each side's second layer, glass fills the middle 3×3 of each side (layers 3–5), and the inner 3×3×5 stays
  empty. When it is not complete, its message now lists the other wrong places too (it used to name only the first).

■ V1.3 "The Washitsu Architectural Masterpiece" — thirty pieces for a Japanese room, and ten factory facilities
- The thirty room pieces have their own new creative tab, OUKA Washitsu. The factory facilities are in the OUKA
  tab.
- The facilities that need power take it from OUKA's power grid, like the V1.2 machines.
- All thirty-seven new sounds are synthesised from nothing (some sounds, such as breaking blocks and wood being set
  down, are vanilla sounds; see Sound below).
- Every recipe is in the recipe book from the start.

■ The room: floors (tatami, engawa, ceiling, wall)
- Igusa Tatami Mat: one mat covers two blocks. An empty-hand right-click changes its border (heri); there are four.
- Stand in a room of **8 or more** joined tatami cells and you get Stamina: hunger drains half as fast.
- Borderless Checkered Tatami: it lies crosswise to a neighbouring checkered mat, so laid together they make a
  checkerboard. Sneak-right-click one with an empty hand to turn it. It counts as a cell of a tatami room.
- Polished Hinoki Engawa Decking, Sugi Cedar Grooved Ceiling and Juraku Earthen Plaster Wall. The ceiling hangs only
  under a solid block. The tatami and the engawa each have their own footsteps.

■ The room: shoji and fusuma
- Shoji Lattice Paper Sliding Door and Gold-Leaf Sansui Fusuma: sliding doors two blocks tall. An empty-hand
  right-click or a redstone signal slides a door open or shut, almost a full block. You can walk through an open one.
- Placed beside another door facing the same way, it takes the other groove, and the two slide past each other.
- Four fusuma in a row make one landscape painting.

■ The room: the lintel, and what fits on it or hangs from it
- Kamoi & Nageshi Lintel Framing: use a Ranma Openwork Transom on it and the ranma fits on top. A Seasonal Kakejiku
  or a Katanakake Sword Stand hangs on its face (when no ranma is fitted); a Bamboo Sudare Roll-up Blind, an Indigo
  Family-Crest Noren or a Cast-Iron Furin hangs underneath.
- Ranma Openwork Transom: sneak-use it to stand it on its own. Light passes through it. An empty-hand right-click
  changes the carving (pine and crane, or waves and plovers).
- Four-Panel Gold Leaf Byobu: stands two blocks wide and two high, to the right of where you place it.
- Bamboo Sudare Roll-up Blind: an empty-hand right-click rolls it (lowered, half, rolled up). Up to three hung one
  under another make one blind.
- Indigo Family-Crest Noren: parts as anyone walks through it.
- The sudare, the noren and the furin hang under a lintel or a solid block, and fall without it.

■ The room: furniture
- Solid Zelkova Low Chabudai: its top has four spaces; right-click one with an item to display it there, and an
  empty hand takes it back. Sneak to place blocks on it. The Matcha Ceremony Whisk & Bowl and the Urushi Lacquer
  Jubako sit on the table top when placed on it.
- Brocade Zabuton and Zaisu Chair & Kyosoku Armrest: right-click with an empty hand to sit; sneak to stand up. The
  zaisu faces whoever placed it, and seats one person at a time.
- Paulownia Tansu with Brass Latches: **27 slots**. Hoppers fill and empty it like a chest. The drawers slide out
  while it is open.
- Matcha Ceremony Whisk & Bowl: right-click with an empty hand to whisk the tea (2 s), then again to drink it. It
  restores full health and gives Haste II for **3 minutes**. One bowl every **5 minutes**, and dying does not reset
  the wait.
- Urushi Lacquer Jubako: holds vanilla foods only, three tiers of three. Break it and the food stays inside the
  item; place it and the food is back. Fire never burns it away.

■ The room: tokonoma and garden
- Shibori Cedar Tokobashira and Seasonal Kakejiku: the scroll hangs two blocks tall on a wall or on a lintel's face.
  Its painting follows the season, a new one every **8 in-game days** (cherry blossom, waterfall, autumn maple,
  snowy peak).
- Bamboo Ikebana, Suiseki Viewing Stone and Celadon Koro Incense Burner stand only on a support. A thread of incense
  smoke rises from the koro; an empty hand puts it out, and flint and steel lights it again.
- Katanakake Sword Stand: right-click with a sword to rest it there, two at most; an empty hand takes the top one
  back. It stands on a floor, or hangs on a wall or on a lintel's face.
- Square Andon Lantern, Hexagonal Bonbori Lamp and Granite Yukimi-Toro Lantern: an empty hand lights them and puts
  them out. The bonbori stands two blocks tall. Snow settles on the yukimi-toro's roof in winter (days 24 to 31 of
  every 32) and always in snowy places.
- Bamboo Shishi-odoshi: the bamboo tube fills, tips and strikes its stone every **4.4 seconds**.
- Cast-Iron Furin: rings in the wind — now and then in a clear breeze, often in rain and storms, never in a closed
  room.
- Kaya Go & Shogi Board: right-click a point with an empty hand to play black and white stones in turn on its nine
  lines; sneak-right-click to take a stone back. Sneak-right-click its side with an empty hand to turn it between go
  and shogi (the stones are cleared).

■ The factory: logistics
- Hyper-Impulse Extractor Hopper: pulls from the container above, vacuums items lying on top, and pushes
  **64 items a tick** (512 times as fast as a vanilla hopper) into the chest or another mod's item pipe its spout
  points at; an OUKA conveyor takes only one a tick. Sneak-use it with an empty hand to set its filter (five slots,
  each set to Exact, Tag or Ignore damage). A redstone signal stops it. It needs no power.
- OUKA Matter Transceiver [32m]: place it on a face of a container (a chest, cauldron, machine or vault port), then
  use a Resonance Linker on the sender and then on its receivers. One sender feeds up to **4 receivers** within
  **32 blocks** in any direction, through walls: up to **64 items** a tick (set from 1 to 64 on its screen) and
  **1 bucket** a tick. Only within one dimension. It needs no power.
- Quantum Vault I/O Bus Terminal: place it against any part of a quantum vault, with a container or a conveyor
  behind it. Export sends the items you choose (up to **9 entries**) into the chest or another mod's item pipe
  behind, up to **256 a tick**, and leaves each entry's keep count in the vault (an OUKA conveyor takes only one a
  tick). Import takes everything in the container behind into the vault. It needs no power.
- Cryo-Fluid Superconductor Pump and Cryo-Fluid Superconductor Pipe: the pump draws from the fluid container on the
  face you place it against and sends into the pipes on its other five faces: **8 buckets a tick**, shared in turn
  among every outlet of the network, all in the same tick (water, lava or any mod's fluid). One network holds up to
  **4,096 pipes**. The pump runs on power (20 kW); the pipes need none. The fission core and the culture vat also
  run on piped water.
- Pocket Dimensional Uplink PDA: use it on a formed vault's controller to bind it, then use it in the air to open
  that vault's screen, even from another dimension. It can put your whole inventory (not the hotbar, not the PDA)
  into the vault. Anyone holding a bound PDA can open the vault, so look after it as you would a key.

■ The factory: production
- Volcanic-Hydraulic Cobblestone Synthesizer: give it a bucket of lava and a bucket of water, which are never used
  up, and it makes whichever you choose: cobblestone (**1 every 8 ticks**), gravel, sand or ore sand. Ore sand
  gives one sand, with a 10 % chance of iron dust and a separate 3 % chance of gold dust. It runs on power (60 kW)
  and pushes what it makes out of its front.
- Autonomous Resonant Miner Head: place it on the rock face you want to mine and put a pickaxe or shovel in its tool
  slot. The area is 1×1, 3×3 or **5×5**, up to **16** deep. Without overclock it takes as long over each block as
  you would with that tool; Silk Touch, Fortune, Efficiency and Unbreaking work as they do for you, and the tool
  wears with each block. It leaves bedrock and chests alone. It runs on power (80 kW) and sends what it mines into
  the container behind it.
- Molecular Micro-Crafter: set a 3×3 pattern and it crafts what that pattern makes on a crafting table (nine iron
  ingots into an iron block, and so on). It takes in only the pattern's items, crafts once a tick (up to
  **10 times** a tick with overclock and a Tachyon Acceleration Pylon), and leftovers such as empty buckets come out
  too. It runs on power (40 kW) and pushes what it makes out of its front.
- Kinetic Stasis Grinder: holds hostile mobs in a **5×3×5** field in front of it and, after a second at normal
  speed, dispatches them for the loot and XP of a player kill. It never touches bosses, named mobs, players or
  villagers. It pulls every loose item in its field into its 27 slots, including anything a player drops there. It
  runs on power (100 kW) and pushes the loot out of its back.
- Aura Capsule: put it in the grinder's capsule slot and it fills with the stored XP (up to **1,395 points** each,
  enough to take a player from level 0 to level 30). Use it to take in all the XP it holds.
- Tachyon Acceleration Pylon: attaches to a face of an OUKA machine that can be overclocked, one per machine, never
  to a vanilla block. An empty-hand right-click steps through 200, 400, 600, 800 and 1000 %; sneak-right-click with
  an empty hand to pick one. It multiplies the Industrial Omni-Wrench's overclock (×1.00 to ×2.50),
  **up to ×10 in all**. It runs on power (40 kW for every 100 % above 100 %), and the machine's power grows with
  the square of its speed.
- The V1.3 facilities that run on power (synthesizer, miner, crafter, pump, grinder) can be overclocked with the
  Industrial Omni-Wrench too.
- The Holographic Circuit Blueprint records and builds each tatami and each byobu as one piece.

■ Fixed since V1.2.0
- Two sounds added in V1.0.1 never played in V1.0.1, V1.1.0 or V1.2.0: the tick as you drag a slider on the OUKA
  Beacon Core Terminal, and the sound as you change a choice on the colour and trajectory selector of the Ouka
  Caster and the Danmaku Focus. Both play now.

■ V1.2 "The Heavy Industrial & Kinematics Epoch" — twenty pieces of heavy industry
- Every machine runs on OUKA's power grid. Tesla pylons join the grid; there are no cables.
- Every machine's movement and sound follow how hard it is working. Every sound is synthesised from nothing;
  nothing is recorded.
- Every recipe is in the recipe book from the start.

■ Power (generation, transmission, storage)
- Wireless Tesla Pylon (two blocks tall): pylons within **64 blocks** of one another form one grid and power the
  OUKA machines near it without wires. While power flows, blue-white arcs run from the pylon to the machines.
- SMES Quantum Battery: **400 MJ**, charging and discharging at up to **2 MW**, with no loss. A hologram on its face
  shows the charge.
- Heavy-Duty Fission Core (5×5×5): up to **2 MW** from uranium or thorium fuel rods. The core glows blue with
  Cherenkov light. At 800 °C the control rods drop and it stops (a scram); it restarts once it has cooled and
  coolant is arriving. It never explodes. Coolant water reaches it through the grid from the desalinator.
- Solar-Thermal Molten Salt Tower (3×3×8): heliostats (flat mirrors, up to 32) within 16 blocks gather sunlight
  and store the heat in molten salt. The turbine gives up to **400 kW**, follows what the grid asks for, and keeps
  running at night on what it stored. A mirror under a roof gathers nothing.

■ Storage and logistics
- Quantum-Compression Vault (5×5×7): build the shell from titanium casing, heat-resistant glass and I/O ports, then
  place the controller on a side to complete it. It holds up to **2,147,483,647 items**; its screen lists the contents
  and filters them by name or by "@mod". The ports (the bottom and each side) connect straight to hoppers, conveyors
  and other mods' pipes. Breaking the controller drops it with a tag of the contents; build the shell again anywhere
  and the contents are the same.
- Maglev Conveyor: carries **20 items a second**. Its shape (straight, curve, slope) follows its neighbours
  automatically. Nothing falls off; when the way is blocked, items queue and wait. You can see each item riding it.
- Maglev Splitter: hands items out one at a time — left, front, right — and skips an exit that is blocked.
- Spectral Sorter: sends each passing item in one of six directions by per-face rules (item, tag, mod,
  data component, or damaged).
- Logistics Drone Port (3×3): sneak-use a Drone Route Card on the destination port, then use it on the sending
  port, and an **Ouka-Cargo Drone** carries loads between the two. At the destination it does not land on the deck,
  which is that port's own drone's place: it hovers beside the port and hands the load over. While the area is
  unloaded, the load still arrives, delayed by the flight time.

■ Smelting and processing
- Blast-Arc Smelting Foundry (3×3×4): takes **32 ores** at a time and smelts **16 times** faster than a furnace.
  You can watch the molten metal run down the trough into the moulds.
- Hydraulic Impact Crusher (two blocks tall): one ore or raw ore makes two dusts (smelt dust into ingots); an ingot
  makes a plate. The hydraulics lift the hammer and slam it down.
- Automated Precision Assembly Line (1×4×2): three robot arms and a press assemble electronic circuits, composite
  plates and machine frames, with welding sparks.
- Molecular Centrifuge Extractor: draws traces of titanium, lithium, quartz and helium-3 from dirt, sand and gravel
  (and lunar regolith). From uranium dust it sometimes yields enriched uranium.

■ Mining and harvesting
- Sub-Crustal Thermal Bore (4×4×6): digs ore and crude oil canisters from deep veins without end, without breaking
  bedrock. **It does not dig in the End** (in the Nether it digs Nether ores).
- Hydro-Vapor Desalinator (3×3×3): placed over water, it pumps from the sources below (at most **200 buckets a
  second**, from a pond two blocks deep). The grid carries the water to the machines that use it (the fission core
  and the culture vat).
- Automated Timber Mill (3×3×2): finds trees within 8 blocks, fells them from the top down, turns them into planks
  and replants the stump.
- Bio-Reactor Culture Vat (3×3×3): cultures industrial plastic, lubricant canisters and stamina serum from organic
  matter and water.

■ Tools and gear
- Industrial Omni-Wrench: use it on a machine to turn it front to back (its contents and work carry on). Sneak-use
  it to open or close a splitter's or sorter's exit, or a conveyor's exit. On a powered processing machine it opens
  the **overclock panel**: choose a speed from ×1.00 to ×2.50 (the faster, the more power each item costs).
- Thermal Demolition Laser: hold it on an OUKA machine for one second and the machine comes apart into your
  inventory with everything inside it (not a drop is spilt).
- Holographic Circuit Blueprint: sneak-use two opposite corners to record what lies between them (up to 16 blocks
  a side). While you hold the recorded blueprint, a **life-size translucent hologram** shows where it will stand
  (cyan where it can be placed, amber where you are short of items, red where the space is taken); use it to build
  it from the items you carry.
- Industrial Hazard Exoskeleton (four pieces): wear all four and electric shocks, heat and falls no longer hurt you,
  you can swim in lava, and you mine three times as fast.

■ Fixed since V1.1.0
- Mining a Block of Ouka Alloy now drops it (it dropped nothing).
- The shelter's loot table was in an old format; it is fixed.

■ The OUKA Beacon
- A 3×3×3 structure. Where you place it becomes the middle of the bottom layer.
- It needs a pedestal: **328 blocks** of netherite, diamond, emerald or Ouka alloy,
  in eight layers (3, 3, 5, 5, 7, 7, 9, 9). It only wakes when all 328 are present.
- Once awake it reaches every player within **1,000 blocks**, even while the beacon's
  own area is unloaded. Spectators receive nothing.
- It gives ten effects (speed, mining speed, attack speed, strength, jump, safe fall,
  absorption, regeneration, food, resistance with partial fire resistance, and night
  vision), each tuned **steplessly from 0.00 to 5.00**, plus the constant effects of
  an enchanted golden apple.
- Right-click any part of it to open a **frosted-glass terminal**: drag a slider, or use
  the mouse wheel in steps of 0.1, or 0.01 with Shift. Three presets are provided:
  ALL MAX, DEFENSIVE MATRIX and MINER'S PARADISE.
- Only the player who placed it, or an operator, may change it, and only from within
  8 blocks. Everyone else sees a read-only terminal.
- Breaking any part removes all 27 and drops one beacon carrying its tuning.

■ The circle projectiles
- The Ouka Caster fires one circle every 0.25 s: straight, spiral or homing.
- The Danmaku Focus fires a barrage every 2 s: converging (twelve circles onto the point
  you are looking at) or orbital guard (eight circles orbit you and launch at an enemy
  within 6 blocks).
- Sneak and use either item to open a holographic selector for colour and trajectory.
- There are twelve colours, each with its own effect: slowness and charm, a screen flash,
  a plasma pillar, double damage to the undead, a pull, a freeze, healing for allies and
  poison for enemies, a line that pierces walls, an 80% cut to a mob's follow range, a
  split into two homing circles, three bounces, and one that cycles the other eleven.
- Where a circle stops, a flat ring spreads and **erases the enemies it crosses**; bosses
  take 20% of their maximum health instead. Players, pets and animals are untouched, and
  no block is broken or set alight.
- A circle in flight leaves a trail in its own colour. Sakura Pink leaves cherry petals,
  which keep falling for several seconds.

■ The Operating Shelter Block (added in V1.1)
- **Only a player with operator permission** can place or break it. Nobody else can, in any
  game mode.
- No explosion gets through, and neither does a mob, a piston, or a creative-mode break.
  It sits in all eleven block tags that vanilla puts bedrock in.
- An operator mines it normally in survival and gets it back (a diamond pickaxe or better).
- When anyone else touches it, a hexagonal energy lattice snaps across its faces, with a
  metallic repulsion and sparks.
- Crafted from 4 obsidian, 4 netherite ingots and 1 block of Ouka alloy, for 2.

■ Sound
- OUKA has **358 sounds** of its own (73 new in V1.6, 15 new in V1.5, 177 new in V1.4, thirty-seven new in V1.3). Every one of them, the
  new ones included, was **synthesised from nothing for OUKA**. No sound from another game, no
  sample library, no recording.
- Vanilla sounds are used for breaking, placing and stepping on OUKA blocks (the V1.2 machines
  included; the tatami and engawa footsteps are OUKA's own), for some of the room's actions (wood
  being set down, drinking the matcha, lighting with flint and steel and so on), for using an Aura
  Capsule, and for a few others.
- **Twelve colours are twelve semitones.** Each circle colour sounds at its own pitch, from
  Sakura Pink to Prismatic Chroma, exactly one octave apart end to end — **you can hear
  which colour flew.**
- The beacon sounds when it is assembled, when it wakes, when it closes and when it breaks
  apart, and hums quietly while it is awake.
- Opening the terminal, and being refused by it, are heard **only by the player it happened
  to** — nobody nearby hears them.
- A gun shot has four layers (mechanism, blast, reverb tail and the supersonic crack). Each gun has its own mechanism and blast sounds, and the
  reverb is chosen from open ground, a canyon or indoors by looking at the surroundings. The tail is not played on every shot of a burst, so busy fire does not use up sound channels.
- The wind turbine has a hum, a blade whoosh, and start, brake and erecting sounds.
- Subtitles are supported.

■ Items and recipes
- Ouka Alloy Ingot / Block of Ouka Alloy (each converts to the other)
- OUKA Beacon
- Ouka Caster
- Danmaku Focus
- V1.2's machines, tools, gear and materials (the V1.2 section above)
- V1.3's thirty room pieces and ten factory facilities, plus the Resonance Linker, the Aura Capsule and the pipe
  (the V1.3 section above)
- V1.4's 15 guns, 6 kinds of ammunition, 14 parts, the wind turbine and 7 shelter glasses (the V1.4 section above)
- V1.6's fifty Japanese-room furnishings and the Grooved Hinoki Sill, the thirty heavy-industry machines and the thirty-two
  materials (the V1.6 section above; the materials are made in machines).
- V1.5's Wrought Iron Statue, the Treasury Door and Treasury Master Key, the Sovereign Battleaxe, the Wrought Plate Ingot
  and four armour pieces, and the Sovereign's spawn egg (the V1.5 section above; the door, the key, the battleaxe
  and the ingot have no recipe)
  The recipes are in the in-game recipe book.

■ Multiplayer
- Install on both the server and the client.
- Every terminal action is checked on the server: values outside the range, and changes
  from anyone without permission, are refused.
- So is the overclock panel: only a player holding the wrench, within 8 blocks, who may build
  there can change it, and nothing outside ×1.00 to ×2.50 is accepted.
- So are the V1.3 facilities' screens (the transceiver, I/O bus, miner, synthesizer, crafter,
  accelerator and the hopper's filter): only a player within 8 blocks who may build there can
  change them.
- Every gun shot, hit and part fitting is decided by the server; the client only predicts with the same rules for feel.
- Every hit on the Wrought Iron Sovereign, and every shock wave of the battleaxe, is decided by the server.
- A product choice on an assembly line is checked on the server: only a player within 8 blocks who may
  build there can change it, and only a real assembly recipe is accepted.
- /ouka reload and /ouka mount are for operators (gamemaster permission).

■ Licences
- OUKA: MIT (LICENSES/OUKA_MIT.txt)
- GeckoLib: MIT (LICENSES/GeckoLib_MIT.txt), bundled unmodified.
