ASTRAEA V1.5.2 "Heavy Industry"
Minecraft 26.3 / Fabric
==================================================================

[日本語]

■ 必要なもの
- Minecraft 26.3
- Fabric Loader 0.19.5 以上
- Fabric API 0.161.0+26.3 以上(この zip には入っていません)
- OUKA 1.4.0 以上(この zip には入っていません。V1.5.2 から必須です)
- Java 25

■ 入れ方(クライアントとサーバーの両方)
1. この zip の mods/ にある jar を、Minecraft の mods フォルダーに入れる。
   - astraea-1.5.2+mc26.3.jar
2. Fabric API と OUKA を同じフォルダーに入れる(上の版以上)。
3. サーバーで遊ぶ場合は、サーバー側にも同じ jar と Fabric API と OUKA を入れる。

■ ご注意
- Fabric API と OUKA 1.4.0 が要ります。ASTRAEA の機械とセキュリティ機器は、OUKA の送電網(テスラパイロンから 64 ブロック以内)
  から給電されます。
- OUKA 1.4.0(26.3)と一緒に入れて試験しています。Alpha との同時導入には対応していません。
- アイテムにカーソルを合わせて Shift を押すと、使い方が出ます(全アイテム)。
- 設定ファイル: config/astraea.json(Aegis の保護機能。すべて既定で有効)。
- V1.5 の機能のスイッチ: config/astraea-sovereign.json。38 の系統と 19 の便利機能を名前ごとに切れます(すべて既定で有効)。
  ゲーム内からは /astraea switch <名前> [true|false](OP 権限レベル 2 以上)。
- 管理者用のコマンド: /aegis(OP 権限レベル 2 以上)— status・integrity・quarantine list / clear / release
- /astraeabench(クライアント): 幻影剣 32 本と毎秒の空間切断を 10 秒間描き、平均フレームレート・1% ロー・最悪のフレームを表示します。

■ 5 つの防壁ドア
- 置いたマスから上へ、幅と高さの分だけ 1 枚の壁として立ちます(幅 3 のドアは置いたマスを中央に、幅 2 のドアは置いたマスを
  左の列にします)。どのマスを壊しても、ドア全体が 1 つのアイテムに戻ります。
- 素手の右クリックか、レッドストーンの信号(入ると開き、切れると閉まる)で開け閉めします。
  通り抜けられるのは、仕掛けが本当に道を空けてからです。
- アイリス絞り型ヘビィ・ブラストドア(3×3): 6 枚の装甲羽根が渦を描いて枠へ畳まれます。
- モノリス油圧式重装両開きゲート(3×3): 閂が抜け、左右の扉が 2 枚折りで畳まれます。
- バイオメトリック・レーザーグリッドドア(2×3): 赤い格子が消え、ガラスが上の枠へ上がります。
- 極低温断熱ハーメチック・ドア(2×3): 4 つの留め金が外れ、蒸気と共に扉がまっすぐ抜けて上へ跳ね上がります。
- アストロラーベ天球ゲート(3×3): 金と白金の 3 つの輪が回って印を揃え、障壁が光になって消えます。

■ 錠(ドア・トラップドア・フェンスゲート・チェスト・樽に付けられます)
- 錠を持ってブロックに使うと取り付けます。付いた錠は、持ち主(と OP)でなければ壊せません。ブロックが壊れると錠も落ちます。
- 施錠中は、レッドストーンでドアや門は開かず、ホッパー(ホッパー付きトロッコ・ドロッパーも)は
  チェストや樽から吸い出しも入れ込みもできません。TNT とピストンは止まりません。
- 開いている錠は、持ち主がスニークして素手で使うと取り外せます(鍵・暗証番号・カードはそのまま残ります)。
- 強化鋼鉄の南京錠: 初めて取り付けたときに鍵(No. 付き)ができます。その鍵で開け閉めします。ピッキングもできます。
- 機械式ダイヤル暗証錠: 取り付けると 4 桁の暗証番号を決めます(スニークして取り付けると番号を消します)。
  正しい番号で 10 秒間開きます。3 回まで間違えられ、その後は 10 秒、倍々に最長 5 分まで入力できません
  (人ごと・錠ごと。ログアウトしても消えません)。
- 生体暗号シリアルスキャナー: 持ち主を登録します。持ち主がスニークして未登録の暗号キーカードを使うと、そのカードを登録します
  (人とカードそれぞれ 16 まで)。登録された人か、登録されたカードを持った人だけが 5 秒間通れます。ほかの人には赤い光とサイレン。

■ ピッキング
- ピッキングツール(ピック 8 本)を、施錠された南京錠に使うと始まります。一人称では、手元の錠に左手でテンションレンチ、
  右手でピックを差して操作します。
- マウスの左右(または A・D)でピックの角度、左ボタンを押し続ける(または Space)とシリンダーを回します。
- 正しい角度に近いほど、カチカチという音が速くなり、シリンダーが大きく回ります。
- 回らない角度で無理に回すと、ピックがしなって錠が震え、やがてピックが折れます。力を抜けば負担は戻ります。Esc でやめます。

■ 天星超合金と 5 つの天星ツール
- 天星超合金: ネザライトインゴット 1・ダイヤモンド 4・アメジストの欠片 4。
- 5 つの道具はネザライトと同じ段の上位の道具です。耐久 4500、採掘速度 14.0。燃えず、奈落に落ちても最後の持ち主の手に戻ります。
  天星超合金で修理できます。
- 天星の削岩鎚: 天星アクションキー(V)で掘る範囲を 1×1・3×3・5×5 に切り替えます。掘ったものはまとめてインベントリへ。
  打ったブロックより硬いものは残します。
- 天星の大伐斧: 丸太を切ると、つながった木を丸ごと(葉まで)伐ります。スニーク中は 1 本だけ。落ちたものは切り株に集まります。
  盾を構えた相手への一撃は盾を貫き、盾を 5 秒間使えなくします。
- 天星の地鎮鍬: スニークして使うと、前方 5×5 を使ったブロックの高さに均します(土・砂・砂利・雪など。石は残ります)。
- 天星の豊穣鎌: 1 マス耕すと周りの 5×5 を耕し、中央を水源にします。実った作物に使うと 5×5 の実りを収穫して植え直します。
- 天星の聖槍: 手の届きが 2.5 ブロック伸びます。走りながら攻撃すると 5.5 ブロック突進して貫きます(攻撃力の 300%)。
  使用を押し続けて放すと、光の槍を投げます(槍は手を離れず、すぐ戻ります)。

■ 宿星刀(天星超合金 2・棒 1。剣の形)
- 攻撃で抜刀します。抜刀そのものが一の太刀です。続けて攻撃すると地上で 4 連、空中で 3 連と兜割り(急降下)。
- 使用(構え)でパリィ。正面からの一撃を完璧な間で受けると、ダメージは無く、相手はよろめきます。矢も弾きます。
- 1.5 秒ほど何もしないと残心の後に納刀します。何かを斬っていれば、鍔が鳴った瞬間に、斬った相手すべてが
  その場で 3 度斬られます(神威のディレイ切断)。
- 大技では、画面が一線に沿って割れる「空間切断」が起きます(ゲームの「画面のゆがみ効果」の設定に従います)。
- 評価ランク(画面右上): 技を当てるほど D → C → B → A → S → SS → SSS と上がります。被弾で下がり、倒れると 0 に戻ります。
- 神性覚醒(SSS で刀を持っている間): 刀の速さ 1.5 倍、移動速度 +30%、攻撃速度 +50%、受けるダメージ半分。
- 星辰の幻影剣: 刀を持って天星アクションキー(V)かマウスの中ボタンで、見えている 24 ブロック以内の敵をロックオンします。
  8 本の光の剣が背後に浮かび、斬るたびに 1 本ずつ敵へ飛びます。
  幻影剣キー(R)で次の技: 螺旋防壁(8 秒間、剣が周りを回って斬る。再使用 12 秒)→ 重力雨(敵の上から降り注ぐ。再使用 15 秒)。
- 魂気: 刀で倒した相手の魂気(最大体力の 5 分の 1)が刀に流れ込みます。
- 天星の炉(鍛冶台でスニークして使う。刀を手に): 修復(摩耗 150 ごとに魂気 1)・鍛錬(次の段 × 10。1 段ごとに一撃 +2.5%、
  20 段で銘刀になり輝く)・討伐数の刻印(+10 に魂気 50)・秘技の解放(討伐数 50: 星落とし、200: 月輪、500: 天割)。

■ V1.1: サイバーセキュリティ(レーザー・カメラ・Corvus Book Pro)
- 電力: テスラパイロンから 64 ブロック以内で OUKA の送電網から給電されます(単位はジュール)。届かないときは内蔵
  バッテリーで動き、切れると止まります。
- セキュリティ・レーザー: 壁・床・天井に付く小型ポッド。持ち主が素手で使うと状態表示、スニークして使うとモード切替(持ち主と OP だけ)。
  - TRIPWIRE(侵入検知): 目に見えない赤外線。横切るとレッドストーン信号を出し、持ち主に警報を送ります。
  - LETHAL(高熱切断): 深紅のビーム。触れた相手を毎秒 10 ダメージで焼きます(防具で軽減)。持ち主・信頼リストの
    プレイヤー・クリエイティブ/スペクテイター、および PvP が無効なサーバーのプレイヤーは焼きません。ブロックは壊しません。
  - ビームは不透明なブロックで止まり、1 区間 32 ブロックまで。光学プリズムで 90 度曲がります(最大 8 区間)。
- セキュリティ・カメラ: 24 ブロック以内・視野 90 度で動くものを見つけ、自動で追います。持ち主に動体警報を送ります。
- Corvus Book Pro: 置いて使うと CorvusOS が開きます(V1.5.2 から。下の「V1.5.2」を参照)。スニークして自分のカメラ・レーザー・電子錠に使うと登録します。
  - 監視モニター: 登録したカメラの実際の映像。クリックで拡大、WASD/矢印キーで首振り、暗視・サーマル、自動追尾の切替。
    映像が出るのは、自分の読み込み範囲内にあるカメラだけです(それ以外は NO SIGNAL)。
  - 電力網管理: OUKA の発電量・蓄電残量のグラフ。
  - 防衛管制: レーザーのモード変更、電子錠の一括施錠/解錠、信頼リストの編集。
  - 信頼リストはコマンドでも編集できます: /astraea trust add|remove <プレイヤー>、/astraea trust list

■ V1.1: プラズマセイバー
- 使用で刃を起動/収納します。起動中だけ武器になります(攻撃力 9)。柄は壊れません。
- 視点を速く回す・振るほど、唸りの音程と音量が上がります。
- 偏向: 起動した刃を振ってから 0.4 秒以内に、正面 60 度以内から飛んできた矢・トライデント・火の玉などが当たると、
  撃った相手へ同じ速さで撃ち返します(落下する矢は弾道を計算して届かせます)。ヒットスキャンの弾は返せません。
- セイバー結晶(6 色: アストレア・シアン、チェリー・クリムゾン、エメラルド・グリーン、アメジスト・パープル、
  ソーラー・ゴールド、純白): ダイヤモンド研磨台に、刃を収納したセイバーを利き手、結晶を反対の手に持って使うと換装します。
  入っていた結晶は手元に戻ります。

■ V1.1: 聖剣エクスカリバーと妖刀村正(作業台では作れません。台座から引き抜きます)
- 聖なる金床台座: オーバーワールドの Y=180 以上、昼、真上に何も無い場所に置くと、聖剣が顕現します。
- 血塗られた怨嗟の祠: Y=0 以下、明るさ 4 以下の場所に置くと、妖刀が顕現します。
- 条件を満たさない場所では眠ったままで、理由を知らせます。条件が整うと目覚めます(夜に置いた台座は朝に目覚めます)。
- 抜刀の儀: 素手で台座を見て、使用を 3 秒押し続けます。離す・目を逸らす・離れると最初からです。
  祠は最大体力の半分を奪います(体力が半分以下の者は引き抜けません。儀式で死ぬことはありません)。
- 引き抜いた台座は二度と剣を生みません(壊しても何も落ちません)。
- エクスカリバー: 使用を 1 秒押し続けて離すと「聖剣の光条」。視線の先 50 ブロック・幅 5 ブロック、壁で止まり、
  30 ダメージ(アンデッドには 1.5 倍で着火)。自分と信頼リストの者は傷つけず、ブロックは壊しません。再使用 10 秒。
  構えている間、16 ブロック以内の自分と信頼リストのプレイヤーに再生能力 II と耐性 II。
- 村正: 宿星刀と同じ操作(抜刀・連撃・パリィ・納刀)。与えたダメージの 2 割を吸収します。
  納刀のディレイ切断は、防具・防具強度・ダメージ軽減エンチャントを無視します(耐性の効果とトーテムは有効)。

■ V1.5: 49 の主権システム(概要)
V1.0・V1.1 の内容はそのままです。V1.5 は次を加えます。数値や作り方は、ゲーム内の「創造の Codex」(下記 20)で調べられます。
- 01 プラズマセイバー V2: 点灯した刃で矢や弾を鏡のように跳ね返し、柔らかいブロックを焼き切ります。
- 02 神託合成作業台: 9×9 の作業台とコアプレス(圧縮コア)。ゼニスの防具一式とゼニスカッターを作ります。
- 03 アクセサリ: 指輪 2・首飾り・ベルト・護符・外套・冠の 7 スロット(H キー)。磁力・活力・嵐・軟着陸・俊足・浮遊・主権の冠。
- 04 スクリプトリア: 印刷機・展示ケース・書庫棚。
- 05 微細ボクセルチゼル: ブロックを 16×16×16 の細かさで彫れます。
- 06 スクリプト NPC: 契約書で雇う従者。役割・台詞・取引・依頼は /astraea npc で決めます(編集画面はありません)。
- 07 家具 100 種: 10 の形(椅子・肘掛け椅子・ソファ・スツール・ベンチ・机・ランプ・シャンデリア・浴槽・暖炉)× 10 の素材。座れるものは座れます。
- 08 エモートホイール: G キー。6 種のエモート。
- 09 エクソスーツ: 加工機で作る装甲服と 4 つのモジュール(ジェット・サーボ・迷彩・フィールド)。
- 10 戦闘車両・航空機: 装甲車と複葉機(木箱から設置)、航空爆弾。
- 11 合成マテリアル: シンセサイザー(プラント)と 8 種の合成素材。
- 12 宇宙開拓: アペックス・ロケットで軌道ステーション・月・火星へ。空気がなく重力が小さい世界です(生命維持ユニットで気密の部屋に空気を満たします)。
  月の岩には鉄鉱石、火星の岩には銅鉱石と金鉱石があります。
- 13 毒ガス: 2 種のガス缶、密閉マスク、ガス洗浄機。
- 14 トレーニングジム: ベンチプレス・スクワットラック・懸垂バー。鍛えると消耗が減ります。
- 15 天狼月相変身: 月の霊薬で人狼に(満月ほど強く)。トリカブトの薬で戻ります。
- 16 視線情報レンズ: 見ているブロックや生き物の情報を表示します。
- 18 弾道ミサイル: サイロ・照準タブレット・迎撃バッテリー。
- 19 重工業: 重粉砕機と高圧送電(鉄塔・変圧器・発電機)。すべてプラントです。
- 20 創造の Codex: 手に持って使うと図鑑の画面が開きます。全アイテムを検索でき、選ぶと作り方を素材までさかのぼって表示します。
  反対の手にアイテムを持って開くと、そのアイテムから始まります(チャットで答える /astraea codex <アイテム> もあります)。
  /astraea codex fill <アイテム> で、開いているクラフトグリッドに材料を並べます。
- 22 ピッキング V2: 5 本のピンがそれぞれの高さで鳴ります。正解から遠い角度で強く回すと、ピックが早く折れます。
- 23 カオス・キューブ: 壊すと何かが起きます。
- 24 ホログラム看板: 名前を付けたアイテムを使うとその名前を、染料で色を、ほかのアイテムでアイコンを空中に映します。レッドストーン信号で消えます。
- 26 ロックダウン制御盤: 16 ブロック以内の ASTRAEA のドアを一斉に封鎖します。
- 27 カメラディレクター: 使うとその場所と向きを記録し、スニークして使うと記録した点を滑らかにたどります
  (クリエイティブかスペクテイターのみ。/astraea camera add <秒> <画角> <傾き>・play・stop・clear)。
- 28 分子分離精錬ライン: 4 台のプラントで鉱石 4 個から 20 個のインゴット。
- 29 魂魄擬態: 魂魄抽出器を反対の手に持って倒した生き物(コウモリ・クモ・ニワトリ・タラ・ウサギ)のエッセンスを飲むと、その大きさと力を得ます。
- 30 防衛トラップ: トラバサミ・クレイモア・スパイクピット・有刺鉄線。
- 32 主権通貨・銀行: 金貨とホロ紙幣、造幣機、ATM(/astraea bank)。
- 33 アバター調整: /astraea avatar <部位> <値>(height・legs・shoulders など)。身長は当たり判定ごと変わります。
- 34 神話級ボス: 鋼鉄の守護騎士・陽光の部族長・霜原の巨獣。それぞれの印章で呼び出します。どの技も、当たる場所を地面の光と体の構えで
  先に見せてから来ます。体力が 6 割・2 割 5 分を切ると段階が進み、技が増えて速くなります。
  守護騎士: 装甲はほとんど通りません。地面を叩いた直後、胸が開いて核が見えている間だけ通ります。
  部族長: 火は効きません。槍の突き・熱波・光の槍・炎の中の踏み込み・裁きの火柱。
  巨獣: 近づくと凍えます。火に弱く、冷気は効きません。牙の薙ぎ・踏み鳴らし・突進・吹雪の息・氷柱。
  倒すとそれぞれの戦利品(守護騎士の核・部族長の日輪・巨獣の牙)を落とします。
- 35 Corvus Book Pro V2: 「Systems」アプリで各システムの状態を一覧します。
- 36 家電・水道: 冷蔵庫・電子レンジ・蛇口と水道管・シーリングファン。食べ物の腐敗は既定で無効です(/astraea spoilage on で有効)。
- 37 カスタム車両: シャーシにエンジン(V8/電動)・タイヤ(オンロード/オフロード)・衝角バンパーを付けて走ります。リードでトロッコやボートを牽引できます。
- 38 熱核分裂炉: 炉心(プラント)・熱交換器・燃料棒・ガイガーカウンター。
- 40 手持ち光源: たいまつなど光るブロックや点灯したセイバーを持つと、周りの地面や壁が照らされます(生き物は照らされません)。
- 41 高圧空力ロジスティクス: コンプレッサー・エアロチューブ・送出機・受取機・安全弁、荷物を運ぶ圧力ドローンとドローンパッド。
- 42 便利機能: チェストの整列(スニーク+素手)、作物の収穫と植え直し、両開きドアの連動、はしごの継ぎ足し、落ち葉の早送りなど 19 種と、
  ブロックを素材に戻すレシピなど 31 種。
- 43 収容プロトコル: 隔壁・監視盤・警報灯・シールド発生機。
- 44 生体認証防衛 V2: 虹彩スキャナー・キーパッド・熱線切断レーザー(OUKA の送電網につなぐと 10 倍の出力になり、壁を切ります)。
- 46 リニアコンベア。
- 47 宿星抜刀術 V2「神威」: スタイルランク SSS で納刀すると、周囲 12 ブロックの敵を止め、1 秒後に 9 回の空間切断が襲います(ランクは S に下がります)。
- 48 戦術装備: 重装の防具一式(ヘルメットはガスマスク)と暗視ゴーグル。
- 49 アストラル錬金術: 坩堝・穢れの浄化器・オーラレンズ。
- 17・21・25・31・39・45 は内部の仕組み(運動学・UI・補間・体の傾き・腕の構え・並列処理)で、置いたり持ったりするものはありません。

■ V1.5.2: 重工業の作り直し(V1.5.0 から変わったこと)
- 機械は「プラント」になりました。1 ブロックではなく、建物の大きさで建ちます。平らで空いた場所でアイテムを使うと、クリックした
  マスから奥へ全体が建ち、置いた人の方を向きます。場所が足りないと置けず、必要な広さが表示されます。どこを使っても開き、
  どこを壊しても全体が 1 つのアイテムに戻ります。
  - 精錬炉 5×5×6(アーク炉)・蒸留塔 3×3×12・結晶化槽 5×5×5・純化装置 5×4×4: 背面中央どうしをつないで 1 列に並べます。
    粉 8 個(または原石 4 個)がインゴット 20 個になります。1 回の処理量は以前の 4 倍、時間も 4 倍で、1 個あたりの電力と水は同じです。
  - シンセサイザー 5×5×5: 金属と OUKA の部品から合成素材を 4 個ずつ(例: 鉄インゴット 16 + OUKA の鉄板 4 → 合成鉄 4)。
  - 重粉砕機 7×7×6: 一体で置きます。外装 25 個とローターで立方体を組む必要はなくなりました(外装とローターは重粉砕機の材料です:
    外装 7・中央にローター・下にレッドストーンブロック)。鉱石 4 個が OUKA の粉 12 個になり、正面中央から出ます。
  - 発電機 7×3×4・変圧器 4×3×5・高圧鉄塔 5×5×20・核分裂炉心 9×9×10。熱交換器は、炉心の建屋の外壁に接して地面に置きます(6 台まで)。
  - 加工する機械(精錬の 4 台・シンセサイザー・重粉砕機)は、どの部分にホッパーやパイプを当てても材料を入れられ、製品を取り出せます。
- V1.5.0 の世界に置いてあった機械は、1 ブロックのまま残り、動きません。壊して置き直してください(中身は落ちます)。
  重粉砕機の立方体に使っていた外装とローターは、そのままブロックとして残ります。
- Corvus Book Pro は「置いて使う」機器になりました。机や床に置き、置いたものを使うと CorvusOS が開きます(手に持ったままでは
  開きません)。開けるのは持ち主と信頼リストの人だけで、8 ブロックより離れると閉じます。カメラなどの登録は今までどおり、
  アイテムを持ってスニークして使います。登録と充電は、置いても壊しても引き継がれます。
- 信頼リストの追加: オンラインのプレイヤーを名前で確実に見つけるようになり、結果が CorvusOS の画面の中に出ます。
  追加は、相手がオンラインのときに行ってください。
- 合成素材・溶融物・金属蒸気・金属結晶・核燃料棒・ガイガーカウンターは、手に持つと立体で見えます。

■ V1.5 でお知らせしておくこと
- 31 の体の動きは、走るときの前傾・跳ぶときの脚・落ちるときの腕です。関節が曲がる変形ではありません。
- 33 で見た目が変わるのは身長・脚の長さ・肩幅と、角・尾・翼です。腕の長さは見た目に出ません。
- 40 は手持ち光源のみです(水面の反射と法線マップはありません)。
- 42 のうち、ピストンでチェストなどを動かす機能と設置アシストは入っていません。

■ キー(設定の「操作」で変えられます)
- 天星アクション: V(ロックオン/削岩鎚の範囲)
- 幻影剣: 次の技: R
- アクセサリを開く: H
- エモートホイール: G

■ レシピ
作業台で作れます: ドア 5 種・錠 3 種・暗号キーカード・ピッキングツール・天星超合金・5 つの道具・宿星刀、
V1.1 のレーザー・プリズム・カメラ・Corvus Book Pro・プラズマセイバー・結晶 6 色・研磨台・2 つの台座。
V1.5 のものは「創造の Codex」で調べられます(ゼニス装備は神託合成作業台で作ります)。
レシピは、作るまでレシピ本には出ません。南京錠の鍵は取り付けのときにできます。

■ ライセンス
MIT(LICENSES/ASTRAEA_MIT.txt)。


==================================================================

[English]

■ Requirements
- Minecraft 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.161.0+26.3 or newer (not included in this zip)
- OUKA 1.4.0 or newer (not included in this zip; required from V1.5.2)
- Java 25

■ Installing (client and server)
1. Put the jar from this zip's mods/ folder into Minecraft's mods folder:
   - astraea-1.5.2+mc26.3.jar
2. Put Fabric API and OUKA into the same folder (the versions above or newer).
3. For a server, install the same jar, Fabric API and OUKA on the server too.

■ Notes
- Fabric API and OUKA 1.4.0 are needed. ASTRAEA's machines and security devices draw their power from OUKA's grid (within 64
  blocks of a Tesla Pylon).
- Tested together with OUKA 1.4.0 (26.3). Installing it together with Alpha is not supported.
- Hold Shift over any item to read how it is used (every item has this).
- Settings: config/astraea.json (the Aegis protections; all on by default).
- Switches for V1.5: config/astraea-sovereign.json. Each of 38 systems and of the 19 conveniences can be turned off by name (all on
  by default); from the game, /astraea switch <name> [true|false] (operator permission level 2 or higher).
- Admin command: /aegis (operator permission level 2 or higher) — status, integrity, quarantine list / clear / release.
- /astraeabench (client): draws 32 phantom blades and a space cut every second for 10 seconds, then reports the average frame
  rate, the 1 % low and the worst frame.

■ Five blast doors
- A door stands as one wall of its width and height, rising from the block you place it on (a 3-wide door is centred on that
  block, a 2-wide door has it as its left column). Breaking any part of it gives back the whole door as one item.
- Open and close it with an empty hand (use) or with redstone (a signal opens it, losing the signal closes it). You can walk
  through only once the mechanism has really cleared the way.
- Iris Aperture Blast Door (3×3): six armoured blades spiral and fold back into the frame.
- Monolithic Hydraulic Double Gate (3×3): the bolts withdraw and each leaf folds as a two-panel concertina.
- Biometric Laser-Grid Hatch (2×3): the red grid powers down and the glass rises into the housing.
- Sub-Zero Hermetic Cryo-Door (2×3): four clamps release, and with a burst of steam the leaf slides straight out and swings up.
- Celestial Astrolabe Gate (3×3): three gold and platinum rings turn until their marks meet, and the barrier dissolves into light.

■ Locks (for doors, trapdoors, fence gates, chests and barrels)
- Use a lock on a block to fit it. Only its owner (or an operator) can break a locked block; if the block breaks, the lock drops.
- While locked, redstone opens no door or gate, and no hopper (nor hopper minecart or dropper) takes from or puts into the
  chest or barrel. TNT and pistons are not stopped.
- The owner takes down an open lock by sneaking and using it with an empty hand; it keeps its key, PIN and cards.
- Hardened Steel Padlock: its numbered key is cut when it is first fitted. The key locks and unlocks it. It can be picked.
- Mechanical Combination Lock: when fitted it asks its owner for a 4-digit PIN (fitting it while sneaking clears the PIN).
  The right PIN opens it for 10 seconds. Three wrong tries are free; after that input is refused for 10 seconds, doubling each
  time up to 5 minutes (per player and per lock; logging out does not reset it).
- Biometric Cipher Lock: enrols its owner. The owner, sneaking, uses a blank Encrypted Keycard on it to enrol the card (up to 16
  people and 16 cards). Enrolled people, and anyone holding an enrolled card, may pass for 5 seconds; anyone else gets the red
  light and the siren.

■ Lockpicking
- Use a Lockpick Kit (8 picks) on a locked padlock. In first person you see the lock at hand: the tension wrench under your left
  hand, the pick under your right.
- Move the mouse left and right (or A and D) to set the pick's angle; hold the left button (or Space) to turn the cylinder.
- The nearer the pick is to the right angle, the faster the clicks and the further the cylinder turns.
- Forcing a cylinder that will not turn bends the pick and shakes the lock until the pick snaps; easing off lets the strain
  relax. Esc stops.

■ Celestial alloy and the five Celestial tools
- Astraea Celestial Ingot: 1 netherite ingot, 4 diamonds and 4 amethyst shards.
- The five tools sit at netherite's tier and above it: 4,500 uses, mining speed 14.0. They do not burn, and one that falls out of
  the world returns to its last holder's inventory. Repair them with the ingot.
- Celestial Pickaxe: the Celestial Action key (V) switches its area between 1×1, 3×3 and 5×5; everything mined goes into your
  inventory. Blocks harder than the one struck are left.
- Celestial Axe: cutting a log fells the whole connected tree, leaves included (sneaking cuts one log); the drops gather at the
  stump. Its blows go through a raised shield and disable it for 5 seconds.
- Celestial Shovel: sneak and use to level the 5×5 ahead to the height of the block used on (earth, sand, gravel, snow …;
  stone is left).
- Celestial Hoe: tilling one block tills the 5×5 around it and makes the centre a water source; used on a ripe crop it harvests
  the 5×5 and replants.
- Celestial Spear: +2.5 blocks of reach. Attack while sprinting to dash 5.5 blocks, piercing everything (300 % damage). Hold use
  and release to throw a spear of light (the spear never leaves your hand; it is back at once).

■ Celestial Blade (2 Celestial Ingots and a stick, in a sword's shape)
- Attack draws it; the draw is the first cut. Keep attacking: four cuts on the ground, or three in the air and a diving
  helm-splitter.
- Use (guard) to parry: a blow from in front caught in the perfect window does no damage and staggers the attacker; arrows are
  turned aside too.
- After about 1.5 seconds without input it rests (zanshin) and is sheathed. If it struck anything, then as the guard clicks home
  every foe it struck is cut again where it stands, three times (the delayed cleave).
- The great strikes part the screen along a line — the space cut (it follows the game's Distortion Effects setting).
- Style rank (top right): landing techniques raises it from D through C, B, A, S and SS to SSS; blows taken lower it; death
  resets it.
- Sovereign awakening (at SSS, blade in hand): blade tempo ×1.5, movement +30 %, attack speed +50 %, half damage taken.
- Phantom starlight blades: with the blade in hand, press Celestial Action (V) or the middle mouse button to lock on to a foe in
  sight within 24 blocks. Eight blades of light hang behind you, and one flies at the foe with each of your cuts. The Phantom
  Blades key (R) calls the next technique: Spiral Drive (8 seconds of blades circling you; 12 s cooldown), then Blistering Rain
  (they fall on the foe from above; 15 s cooldown).
- Soul energy: each foe the blade fells pours a fifth of its maximum health into it as soul energy.
- The Celestial Forge (sneak and use a smithing table, blade in hand): mend (1 soul energy per 150 points of wear), temper
  (10 × the next level; +2.5 % to every blow per level; the twentieth makes a named blade that gleams), inscribe defeats
  (+10 for 50 soul energy), and unlock the secret arts (at 50, 200 and 500 defeats: Starfall, Lunar Ring, Heaven's Rift).

■ V1.1: Cyber-security (laser, camera, Corvus Book Pro)
- Power: a device within 64 blocks of a Tesla Pylon draws from OUKA's grid (in joules). Out of reach it runs on its backup
  battery and stops when that is empty.
- Security Laser: a small pod for walls, floors and ceilings. Its owner (or an operator) uses it with an empty hand for its status, and
  sneaks and uses it to switch mode.
  - TRIPWIRE: an invisible infrared beam. Crossing it gives a redstone signal and alerts the owner.
  - LETHAL: a crimson beam that burns whatever touches it for 10 damage a second (armour reduces it). It never burns its
    owner, players on the owner's trust list, creative or spectator players, or any player on a server with PvP off. It
    breaks no block.
  - A beam stops at opaque blocks and runs up to 32 blocks a segment; an Optical Prism turns it 90° (up to 8 segments).
- Security Camera: sees movement within 24 blocks inside a 90° view and follows it; it sends its owner a motion alert.
- Corvus Book Pro: set it down and use it to open CorvusOS (from V1.5.2; see the V1.5.2 section below). Sneak and use it on your
  own camera, laser or electronic lock to link it.
  - Surveillance: the real view from each linked camera. Click to enlarge; WASD or the arrow keys turn the camera; night
    vision, thermal and auto-track switches. Only cameras inside your loaded area have a picture (others read NO SIGNAL).
  - Grid Telemetry: OUKA's generation and stored energy as a graph.
  - Firewall: laser modes, lock or unlock every linked electronic lock, and the trust list.
  - The trust list has a command too: /astraea trust add|remove <players>, /astraea trust list

■ V1.1: Plasma Saber
- Use ignites or retracts the blade. It is a weapon only while lit (9 attack damage). The hilt never wears out.
- The faster you turn or swing it, the higher and louder it hums.
- Deflection: an arrow, trident, fireball or other projectile that would hit you within 0.4 s of swinging the lit blade, from
  within 60° of where you are looking, is sent back at whoever loosed it at its own speed (a falling arrow is aimed so that it
  arrives). Hit-scan shots cannot be returned.
- Saber Crystals (six: Astraea Cyan, Cherry Crimson, Emerald Green, Amethyst Purple, Solar Gold, Pure White): at a Diamond
  Polishing Bench, hold the retracted saber in your main hand and a crystal in the other and use the bench. The crystal that
  was fitted comes back to you.

■ V1.1: Excalibur and Muramasa (never crafted: drawn from their pedestals)
- Hallowed Anvil Pedestal: placed in the Overworld at Y 180 or higher, by day, with nothing above it, it manifests Excalibur.
- Blood-Bound Shrine: placed at Y 0 or deeper in light of 4 or less, it manifests Muramasa.
- Elsewhere a pedestal sleeps and tells you why; it wakes when its conditions are met (one set down at night wakes at dawn).
- The draw: with an empty hand, look at the pedestal and hold use for three seconds. Letting go, looking away or stepping back
  starts it over. The shrine takes half of your maximum health (it refuses anyone at half health or less; it never kills).
- A pedestal gives its sword once; afterwards it drops nothing when broken.
- Excalibur: hold use for a second and let go for the Excalibur Ray — 50 blocks along your view and 5 wide, stopped by walls,
  30 damage (half as much again to the undead, and it sets them alight). It spares you and those you trust and breaks no
  block. 10 s cooldown. While it is in your hand, you and trusted players within 16 blocks have Regeneration II and
  Resistance II.
- Muramasa: the Celestial Blade's controls (draw, combo, parry, sheathe). It returns a fifth of the damage it deals as health.
  Its sheathing cleave ignores armour, armour toughness and protection enchantments (Resistance and totems still work).

■ V1.5: the 49 sovereign systems (overview)
Everything in V1.0 and V1.1 is unchanged. V1.5 adds the following. Numbers and recipes can be looked up in the game with the Codex
of Creation (20, below).
- 01 Plasma Saber V2: the lit blade turns arrows and shots back like a mirror and burns through soft blocks.
- 02 Oracle Crucible: a 9 × 9 crafting bench and the Core Press (compressed cores); they make the Zenith armour and the Zenith Cutter.
- 03 Accessories: seven slots — two rings, necklace, belt, charm, cloak, crown (H key). Magnetism, vigour, storm, featherfall,
  swiftness, levitation and the Sovereign Crown.
- 04 Scriptoria: a press, a display case and an archive shelf.
- 05 Micro-Voxel Chisel: carve a block at 16 × 16 × 16.
- 06 Scripted NPCs: a retainer hired with a contract; its role, lines, trades and quests are set with /astraea npc (there is no
  editing screen).
- 07 A hundred furnishings: ten forms (chair, armchair, sofa, stool, bench, table, lamp, chandelier, bathtub, fireplace) in ten
  materials. What looks like a seat is one.
- 08 Emote wheel: G key, six emotes.
- 09 Exosuit: armour made at the Fabricator, with four modules (jet, servo, cloak, field).
- 10 War machines: an armoured car and a biplane (set down from their crates), and the aerial bomb.
- 11 Synthesis materials: the Synthesizer (a plant) and eight synthesis materials.
- 12 Cosmic frontier: the Apex Rocket goes to the Orbital Station, the Moon and Mars — no air and low gravity (a Life-Support Unit
  fills a sealed room with air). The Moon's rock holds iron ore; Mars's holds copper and gold ore.
- 13 Toxic gas: two gas canisters, the Sealed Mask and the Gas Scrubber.
- 14 Conditioning gym: bench press, squat rack, pull-up bar. Training lowers what exertion costs you.
- 15 Celestial lycanthropy: the Lunar Elixir makes a werewolf (stronger the fuller the moon); the Wolfsbane Tonic ends it.
- 16 Glance Lens: shows what you are looking at.
- 18 Missile complex: silo, targeting tablet, interceptor battery.
- 19 Heavy industry: the Heavy Mill and high-voltage power (pylon, transformer, dynamo), all plants.
- 20 Codex of Creation: use it to open its screen — every item, searchable; choose one and see what it is made of, all the way
  down to raw materials. Open it with an item in your other hand and it starts from that item (/astraea codex <item> answers in
  chat). /astraea codex fill <item> lays the recipe out in the crafting grid you have open.
- 22 Lockpicking V2: five pins click, each at its own pitch; leaning hard on the wrench far from the right angle snaps the pick sooner.
- 23 Chaos Cube: break it and something happens.
- 24 Holographic Sign: use a named item on it to project the name, a dye to colour it, any other item for an icon. A redstone signal
  switches it off.
- 26 Lockdown Console: seals every ASTRAEA door within 16 blocks.
- 27 Camera Director: use it to record where you stand and look; sneak-use to travel smoothly through the recorded points (creative
  or spectator only; /astraea camera add <seconds> <fov> <roll>, play, stop, clear).
- 28 Molecular refinery: four plants turn four ores into twenty ingots.
- 29 Soul metamorphosis: kill a bat, spider, chicken, cod or rabbit with the Soul Extractor in your other hand and drink its essence
  to take its size and its gift.
- 30 Perimeter traps: bear trap, claymore, spike pit, barbed wire.
- 32 Sovereign mint and bank: gold sovereigns and holo-notes, the mint, the ATM (/astraea bank).
- 33 Avatar sculptor: /astraea avatar <part> <value> (height, legs, shoulders and more). Height changes your hit box too.
- 34 Mythic bosses: the Steel Guardian, the Sunlit Chieftain and the Frostfield Behemoth, each called with its sigil. Every
  move is shown first — by light on the ground where it will land and by the body's stance — and then comes. Below 60% and 25%
  of its health a boss enters a new phase: more moves, and faster.
  Guardian: its plate turns almost everything; only just after it slams the ground, while its chest stands open and the core
  shows, does a blow go through.
  Chieftain: fire does nothing to it. A spear thrust, a heat wave, a lance of light, a step through flame, pillars of fire.
  Behemoth: standing close to it freezes you; fire hurts it more, cold not at all. A tusk sweep, a stomp, a charge, a breath
  of frost, icicles.
  Each leaves a trophy: the Guardian's Core, the Chieftain's Sun Disc, the Behemoth's Tusk.
- 35 Corvus Book Pro V2: the Systems app lists how every system is doing.
- 36 Home appliances: refrigerator, microwave, faucet and water pipe, ceiling fan. Food spoilage is off by default
  (/astraea spoilage on turns it on).
- 37 Modular vehicles: fit a chassis with an engine (V8 or electric), tyres (road or off-road) and a ram bumper. A lead hitches a
  minecart or a boat behind it.
- 38 Fission plant: the core (a plant), heat exchanger, fuel rods, Geiger counter.
- 40 Held light: a torch, anything that glows as a block, or a lit saber in your hand lights the ground and walls round you
  (it does not light creatures).
- 41 High-pressure pneumatics: compressor, aero-tube, sender, receiver, safety valve, and a pressure drone that flies cargo between
  drone pads.
- 42 Conveniences: nineteen behaviours — sort a chest (sneak with empty hands), harvest and replant, double doors that move together,
  ladders hung at the foot of a run, fast leaf fall and more — and thirty-one recipes such as blocks back into their materials.
- 43 Containment protocol: bulkhead, cell monitor, alarm strobe, shield projector.
- 44 Biometric defence V2: retina scanner, keypad, thermal cutting laser (on OUKA's grid it burns ten times as hard and cuts walls).
- 46 Maglev conveyor.
- 47 Celestial Blade Engine V2, "Kamui": sheathe at style rank SSS and every foe within 12 blocks is held, then cut nine times a
  second later (the rank falls to S).
- 48 Tactical ordnance: a heavy armour set (the helmet is a gas mask) and night-vision goggles.
- 49 Astral alchemy: crucible, taint purifier, aura lens.
- 17, 21, 25, 31, 39 and 45 are internals (kinematics, UI, interpolation, body carriage, arm aim, parallel work): nothing to place
  or hold.

■ V1.5.2: heavy industry rebuilt (what changed since V1.5.0)
- The machines are now plants: not one block but the size of a building. Use the item on clear, level ground and the whole
  plant rises from the block you click, away from you, facing you. Without room it is not placed and you are told the room
  it needs. Using any part opens it; breaking any part returns the whole plant as one item.
  - Refinery Smelter 5×5×6 (an arc furnace), Still 3×3×12, Crystalliser 5×5×5, Purifier 5×4×4: stand them in a row, each
    against the middle of the back of the one before. Eight dust (or four raw ore) become twenty ingots. A batch is four times
    what it was and takes four times as long; the power and water for each item are the same.
  - Synthesizer 5×5×5: four synthesis materials at a time from a metal and an OUKA part (for example 16 iron ingots and 4 OUKA
    Iron Plates make 4 Synthesis Iron).
  - Heavy Mill 7×7×6: placed whole. The cube of 25 casings and a rotor is no longer built (the casing and the rotor are what the
    mill is crafted from: seven casings, the rotor in the middle, a block of redstone below). Four ores become twelve OUKA dust,
    which leaves at the middle of the front.
  - Dynamo 7×3×4, Transformer 4×3×5, High-Voltage Pylon 5×5×20, Fission Core 9×9×10. Heat Exchangers stand on the ground against
    the outside wall of the core's hall (six at most).
  - The machines that process things (the four refinery stages, the Synthesizer, the Heavy Mill) take their inputs and give their
    products through a hopper or pipe against any part of them.
- Machines standing in a V1.5.0 world stay as single blocks and do not work: break them and set them down again (their contents
  drop). Casings and rotors of an old mill cube stay as blocks.
- The Corvus Book Pro is now a device you set down: put it on a desk or the floor and use it where it stands to open CorvusOS
  (in the hand it opens nothing). It opens for its owner and the players on the owner's trust list, and closes when you are more
  than 8 blocks away. Linking a camera, laser or lock is as before: hold the item, sneak and use it on the device. Its links and
  its charge are kept when it is set down and when it is broken.
- Adding to the trust list: a player who is online is now found by name reliably, and the result is shown inside the CorvusOS
  window. Add a player while they are online.
- Synthesis materials, molten slag, metal vapour, metal crystal, the fuel rod and the Geiger counter have bodies of their own
  in the hand.

■ V1.5: what you should know
- Body motion (31) is a lean into a run, legs drawn up in a leap and arms out in a fall. Limbs do not bend at joints.
- The avatar sculptor (33) changes height, leg length, shoulder width, horns, a tail and wings to the eye. Arm length is not drawn.
- 40 is held light only (no water reflection, no normal maps).
- Of 42, pistons moving chests and the like, and placement assist, are not included.

■ Keys (change them under Controls)
- Celestial Action: V (lock on / pickaxe area)
- Phantom Blades, next technique: R
- Open Accessories: H
- Emote Wheel: G

■ Recipes
Made at a crafting table: five doors, three locks, the Encrypted Keycard, the Lockpick Kit, the Celestial Ingot, the five tools
and the Celestial Blade; and V1.1's laser, prism, camera, Corvus Book Pro, Plasma Saber, six crystals, polishing bench and the
two pedestals. V1.5's can be looked up with the Codex of Creation. A recipe shows in the recipe book once you have made it. A padlock's key is cut when the padlock is
fitted.

■ Licence
MIT (LICENSES/ASTRAEA_MIT.txt).
