# Corvus agent (V4)

A small program that keeps a Minecraft Fabric server on the same brand mods as the Corvus Store. It reads the same
manifest the Store reads, checks each downloaded file against the manifest's size and SHA-256, and replaces only the
jars of the brands listed in its configuration.

Status: **4.1.1 (managed mode).** The 4.0.0 behaviour is still there as "external" mode. See "Not verified" for what
has not been run.

## From Corvus Store (no command prompt)

If you use Corvus Store on the same computer as the server, the Store can do the set-up for you. Open the Store, find
**Corvus Agent**, press its button and choose the server's folder (the folder that contains `mods`, or `server.jar`, or
a start script). The Store downloads the agent, checks it against the published size and SHA-256, and puts it in the
folder as `corvus-agent.jar`. It also writes `corvus-agent.json`, `start-with-corvus.bat` and `start-with-corvus.sh`,
which run `corvus-agent.jar`, and lists the mods it finds in `"brands"`.

If the folder already has a start script from an earlier hand set-up that names a different jar, the Store leaves that
script alone and tells you the one line to change: the jar name must become `corvus-agent.jar`.

From then on, start the server with `start-with-corvus.bat` (or `start-with-corvus.sh` on Linux and macOS). When a new
agent is published, the Store offers an update. It replaces `corvus-agent.jar` and nothing else: the scripts and
`corvus-agent.json` are not touched. If the server is running, the jar is locked (on Windows), so the Store says to
stop the server and press Update again.

The Store never starts, stops or talks to the server. The rest of this file is for doing the same by hand.

## The quick way (Windows, a server you start from a .bat)

You run the server by double-clicking a `.bat` file. After these steps the agent starts the server for you, watches it,
and updates the mods by itself.

1. **Install Java 25** if `java -version` (in Command Prompt) shows a version below 25. Use any Java 25 build (for
   example Eclipse Temurin 25) and tick the option that adds Java to the PATH.
2. **Put `corvus-agent-4.1.1.jar` in your server folder**, the folder that contains `mods`, next to your current `.bat`.
3. **Open Command Prompt in that folder** (click the address bar, type `cmd`, press Enter) and run:

       java -jar corvus-agent-4.1.1.jar --init .

   It writes `corvus-agent.json` and `start-with-corvus.bat` into the folder, and tells you what it found. It never
   overwrites an existing `corvus-agent.json`.
4. **Open `corvus-agent.json` in Notepad.** Edit `"brands"`: keep only the brands this server runs. The valid names are
   `cherry`, `ouka`, `astraea`, `tsubomi` and `halia`. The file says `tsubomi` as a placeholder. Check that
   `"serverCommand"` is the command your `.bat` runs (`--init` copies it from the `.bat`). `--init` also reads the `mods` folder and lists the brands it finds.
5. **From now on start the server with `start-with-corvus.bat`** (double-click it), not with the old `.bat`.
6. **What the window shows:** the server's log, exactly as before, with the agent's own lines (with UTC times) in
   between. Type server commands as usual: `say hello`, `op name`.
7. **Stopping:** typing `stop` in the window still stops the server and saves the world. The window then closes by
   itself.
8. **Mods update by themselves.** About every ten minutes the agent checks the site. When a new version is published
   and no player is online, it stops the server, copies the mods folder to a backup, replaces the jars, starts the
   server again, and checks that it answers. If players are online it waits and tries again in ten minutes.
9. **Backups** are in `.corvus-backup\<time>\` inside the server folder. The five newest are kept.

When the agent starts it checks for updates first, installs them, and only then starts the server, so a server that
was switched off over an update comes up on the new mods.

If the server crashes, the agent says so and starts it again after ten seconds (`--init` writes
`"restartOnCrash": true`). After three restarts within ten minutes it gives up, says so, and closes. With
`"restartOnCrash": false` it closes after the first crash. An agent never stays open with no server behind it.

Closing the window or pressing Ctrl+C also stops the server, and the agent asks it to save first. On Windows, Ctrl+C
is delivered to every program in the window, the server included, so use `stop` when you want a clean save.

## Configuration

`corvus-agent.json` is read from `--config <file>`. Relative paths are relative to the file. Unknown fields are refused,
so a typo cannot silently change nothing.

| Field | Mode | Meaning |
| --- | --- | --- |
| `mode` | both | `"managed"`: the agent starts the server as its child and owns its console. `"external"` (default): the agent runs `stopCommand` and `startCommand`. |
| `serverDir` | both | The server folder. Must exist. `mods/` is inside it. Commands run here. |
| `brands` | both | Brand blocks the server runs: `cherry`, `ouka`, `astraea`, `tsubomi`, `halia`. Only these are ever installed or updated. |
| `serverCommand` | managed, required | The command that starts the server, as a list, such as `["java", "-Xmx4G", "-jar", "fabric-server-launch.jar", "nogui"]`. Must not be empty. A `.bat` or `.cmd` is run through `cmd.exe /c`. Ignored in external mode. |
| `pollMinutes` | both | How often the agent syncs on its own. `0` means never (only on request). Default 10 in managed mode, 0 in external mode. |
| `restartOnCrash` | managed | `true` starts the server again after an unexpected exit (after 10 seconds, at most 3 times in 10 minutes), then the agent closes. Default `false`; `--init` writes `true`. |
| `stopCommand` / `startCommand` | external, required | Commands run in `serverDir`. The stop command must end the server; the start command should launch it and return. Ignored in managed mode. |
| `manifestUrl` | both | The manifest address. https only (http only for 127.0.0.1 or localhost). Defaults to the published manifest. |
| `token` | when `listenPort` > 0 | Bearer token for the HTTP endpoint. At least 32 characters. Never printed. |
| `listenHost` / `listenPort` | both | Where the HTTP endpoint listens. `listenPort` `0` means no HTTP endpoint and no token is needed. Default: 0 in managed mode, 8931 in external mode. |
| `statusHost` / `statusPort` | both | Where the Minecraft status ping is sent. Defaults to 127.0.0.1:25565. |
| `startTimeoutSeconds` | both | How long to wait for the server to answer after a start. Default 600. |
| `stopTimeoutSeconds` | both | How long the server may take to stop. Default 60. In managed mode, after this the process is destroyed. |
| `waitForEmptyMinutes` | both | 0 (default): never update while players are online. More than 0: postpone, and proceed after that many minutes. |

## Running

    java -jar corvus-agent-4.1.1.jar --init <serverDir>                   # write a managed configuration (never overwrites)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json --plan    # what would change; changes nothing (both modes)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json --once    # one sync, then exit (external mode only; 0 = done or deferred)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json           # stay up

In managed mode `--once` is refused with exit code 2: a one-shot run cannot own a server that keeps running.

Every line is printed with a UTC time. The token is never printed.

## The HTTP endpoint (when `listenPort` is above 0)

Bound to 127.0.0.1 unless the configuration says otherwise.

- `POST /api/v4/sync` with `Authorization: Bearer <token>`: starts one sync in the background. Answers 202 `STARTED`
  or 202 `ALREADY_RUNNING`. The request body is read and ignored.
- `GET /api/v4/status` with the same header: version, brands, whether a run is in progress, the last result.

A wrong or missing token is 401. A sixth wrong attempt from one address within ten minutes is 429 for the next ten
minutes, even with the right token. The endpoint has no TLS of its own: put it behind a proxy or a tunnel to reach it
from the internet.

## The scheduled sync and the one-run rule

The timer (`pollMinutes`) and the HTTP endpoint share one guard: at most one sync runs at a time, whichever asked for
it. The first timer check comes `pollMinutes` after start, so the server has time to boot; the agent logs a plan at
start. A check that finds players online is postponed, and the next check tries again.

## What a sync does, in order

1. Reads the manifest and compares each listed brand with the jar in `mods/` that declares its mod id.
   Nothing to do: the server is not touched.
2. Downloads each needed file to `.corvus-staging/` and checks its size and SHA-256. Any mismatch stops the run;
   nothing is stopped or changed.
3. If players are online, postpones (unless `waitForEmptyMinutes` says to wait).
4. Copies the mods folder to `.corvus-backup/<UTC timestamp>/`: every file in `mods/`, so a roll-back puts back exactly
   what was there.
5. Stops the server. In managed mode the agent writes `stop` to the server's console and waits for the process to exit,
   and destroys it only after `stopTimeoutSeconds`. In external mode the stop command runs and the agent waits for the
   status ping to go silent.
6. Installs each brand with the same installer the Store uses: one jar per mod id, the installer's own checks, and its
   own roll-back.
7. Starts the server and polls its status ping until it answers or the start timeout passes.
8. If the installer failed, or the server did not answer: puts the backup back, starts the server again, and reports it.

Nothing is removed from `mods/` except jars of the listed brands (found by mod id), and the installer's own staging
names. Other mods, and any file a player put there, are byte-identical after a run.

The five newest backups are kept.

## External mode (4.0.0 behaviour)

Set `"mode": "external"`, or leave it out. The agent does not start the server; the stop and start commands do. Use
`corvus-agent.external.example.json` as the starting point. On Windows a `stopCommand` or `startCommand` whose first
element ends in `.bat` or `.cmd` is run through `cmd.exe /c`.

A scheduled run needs no Store: `--once` from cron or a systemd timer, or a `pollMinutes` value above 0.

## Linking Corvus Store

Corvus Store 4.0.0 and later: Account, then "Linked server". Switch it on, give the agent's address and the token from
this configuration, and press "Test connection". After the Store installs or updates a mod it sends one request to the
agent, which then syncs the server to the site's manifest. This needs `listenPort` above 0. Plain `http` is accepted by
the Store only for this computer or a local network address; for a server on the internet put the agent behind an
`https` reverse proxy or a tunnel.

## Verified on a real server (4.0.0, 12 October 2026, macOS, Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.161.0)

- First install from the live site into a running server: Tsubomi 1.1.0 (a bare jar), Cherry 1.2.0 (a ZIP, with its
  GeckoLib) and Halia 1.0.0 were downloaded and verified, the server was stopped, the jars placed, the server started,
  and it answered its status ping with the three mods loaded. Fabric API in the folder was untouched.
- An update: Tsubomi 1.0.1 in a running server became 1.1.0.
- A real roll-back: with a start timeout too short for a real server, the agent stopped the half-started server, put
  the previous jars back (the folder was byte-identical to before), and started it again; one server process was left.
- The HTTP endpoint: no token and a wrong token got 401; the right token started a sync; a second request at once got
  ALREADY_RUNNING; a request body naming another manifest address had no effect; the status reported UPDATED.
- Corvus Store's own client against the running agent: status CONNECTED, a wrong token UNAUTHORISED, sync STARTED.

## Not verified

- **Managed mode has not been run against a real Minecraft server, and not on Windows.** Its tests use a fake child
  process (`FakeMinecraftServer`, started with the same Java as the tests) on macOS. The Windows test step is in
  `.github/workflows/windows-tests.yml` and has not been run.
- Typing into the console of a real server through the agent's pass-through, and the window's close and Ctrl+C on
  Windows (see above). A `.bat` run through `cmd.exe /c` with arguments that contain spaces is untested.
- The start scripts (`start-with-corvus.bat`, `start-with-corvus.sh`) have not been double-clicked or run.
- The server's output is read as UTF-8. A server that prints in another encoding on Windows may show odd characters.
- Restarts after a crash of a real server (`restartOnCrash`).
- Linux and Windows servers as the external mode's stop and start commands; systemd, Docker or a hosting panel.
- A server that fails to start because a mod is broken (the roll-back was forced with a short timeout instead).
- The player gate with a real player online (tested with a scripted fake only).
- The endpoint has no TLS of its own. Do not open it to the internet without a proxy or a tunnel in front of it.
- "Wait N minutes while players are online" only proceeds when a later check comes round, which the timer or a request
  makes; the agent does not sleep through the wait.
