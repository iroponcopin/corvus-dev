# Corvus agent (V4, Phase 1)

A small program that keeps a self-hosted Minecraft server on the same brand mods as the Corvus Store. It reads the
same manifest the Store reads, checks the files it downloads against the manifest's size and SHA-256, and replaces
only the jars of the brands listed in its configuration.

Status: **4.0.0. Unit-tested, and run against one real Minecraft 26.3 Fabric server on macOS** (see "Verified on a real server" and "Not verified" below).

## Build

    ./gradlew --offline :agent:test :agent:fatJar

The jar is `agent/build/libs/corvus-agent-4.0.0.jar`. It needs Java 25 and has no other dependencies.

## Configuration

Copy `corvus-agent.example.json` and edit it. Fields:

| Field | Required | Meaning |
| --- | --- | --- |
| `serverDir` | yes | The server folder. Must exist. `mods/` is inside it. |
| `manifestUrl` | no | The manifest address. https only (http only for 127.0.0.1 or localhost). Defaults to the published manifest. |
| `brands` | yes | Brand blocks the server runs, such as `"tsubomi"`. Only these are ever installed or updated. |
| `token` | yes | Bearer token for the HTTP endpoint. At least 32 characters. Never printed. |
| `listenHost` / `listenPort` | no | Where the HTTP endpoint listens. Defaults to 127.0.0.1:8931. |
| `stopCommand` / `startCommand` | yes | Commands run in `serverDir`. The stop command must end the server; the start command should launch it and return. |
| `statusHost` / `statusPort` | no | Where the Minecraft status ping is sent. Defaults to 127.0.0.1:25565. |
| `startTimeoutSeconds` | no | How long to wait for the server to answer after a start. Default 600 (a real 26.3 server with three mods took 160 seconds on a busy machine). |
| `stopTimeoutSeconds` | no | How long the stop command and the server's shutdown may take. Default 60. |
| `waitForEmptyMinutes` | no | 0 (default): never update while players are online. More than 0: postpone, and proceed after that many minutes. |

Unknown fields are refused, so a typo cannot silently change nothing.

## Running

    java -jar corvus-agent-4.0.0.jar --config corvus-agent.json --plan    # what would change; changes nothing
    java -jar corvus-agent-4.0.0.jar --config corvus-agent.json --once    # one sync, then exit (0 = done or deferred)
    java -jar corvus-agent-4.0.0.jar --config corvus-agent.json           # stay up, serve the HTTP endpoint

The HTTP endpoint (bound to 127.0.0.1 unless the configuration says otherwise):

- `POST /api/v4/sync` with `Authorization: Bearer <token>`: starts one sync in the background. Answers
  202 `STARTED` or 202 `ALREADY_RUNNING`. The request body is read and ignored.
- `GET /api/v4/status` with the same header: version, brands, whether a run is in progress, the last result.

A wrong or missing token is 401. A sixth wrong attempt from one address within ten minutes is 429 for the next ten
minutes, even with the right token.

## What a sync does, in order

1. Reads the manifest and compares each listed brand with the jar in `mods/` that declares its mod id.
   Nothing to do: the server is not touched.
2. Downloads each needed file to `.corvus-staging/` and checks its size and SHA-256. Any mismatch stops the run;
   nothing is stopped or changed.
3. If players are online, postpones (unless `waitForEmptyMinutes` says to wait).
4. Copies the mods folder to `.corvus-backup/<UTC timestamp>/`. This is a copy of every file in `mods/`, so the roll-back
   puts back exactly what was there, including any dependency jar the installer might replace.
5. Stops the server if its status ping answered.
6. Installs each brand with the same installer the Store uses (core's `BrandInstaller`): one jar per mod id, the
   installer's own checks, and its own roll-back.
7. Starts the server and polls its status ping until it answers or the start timeout passes.
8. If the installer failed, or the server did not answer: puts the backup back, starts the server again, and reports it.

Nothing is removed from `mods/` except jars of the listed brands (found by mod id), and the installer's own staging
names. Other mods, and any file a player put there, are byte-identical after a run.

The five newest backups are kept; older ones are deleted when a new one is made. Each backup is a full copy of the mods
folder under `.corvus-backup/`.

## Linking Corvus Store

Corvus Store 4.0.0 and later: Account, then "Linked server". Switch it on, give the agent's address and the token from
this config, and press "Test connection". After the Store installs or updates a mod it sends one request to the agent,
which then syncs the server to the site's manifest. Plain `http` is accepted by the Store only for this computer or a
local network address; for a server on the internet put the agent behind an `https` reverse proxy or a tunnel.

A scheduled run needs no Store: `java -jar corvus-agent-4.0.0.jar --config corvus-agent.json --once` from cron or a
systemd timer.

## Verified on a real server (12 October 2026, macOS, Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.161.0)

- First install from the live site into a running server: Tsubomi 1.1.0 (a bare jar), Cherry 1.2.0 (a ZIP, with its
  GeckoLib) and Halia 1.0.0 were downloaded and verified, the server was stopped, the jars placed, the server started,
  and it answered its status ping with the three mods loaded. Fabric API in the folder was untouched.
- An update: Tsubomi 1.0.1 in a running server became 1.1.0.
- A real roll-back: with a start timeout too short for a real server, the agent stopped the half-started server, put
  the previous jars back (the folder was byte-identical to before), and started it again; one server process was left.
- The HTTP endpoint: no token and a wrong token got 401; the right token started a sync; a second request at once got
  ALREADY_RUNNING; a request body naming another manifest address had no effect; the status reported UPDATED.
- Corvus Store's own client against the running agent: status CONNECTED, a wrong token UNAUTHORISED, sync STARTED.

## Not verified

- The player gate with a real player online (tested with a scripted fake only).
- Linux and Windows servers; systemd, Docker or a hosting panel as the stop and start commands. The tests used two
  shell scripts on macOS.
- A server that fails to start because a mod is broken (the roll-back was forced with a short timeout instead).
- `ProcessServerControl` has no unit test of its own. The start command is not destroyed when it is still running
  after 30 seconds, because killing a launcher can kill the server it started.
- The endpoint has no TLS of its own. Do not open it to the internet without a proxy or a tunnel in front of it.
- "Wait N minutes while players are online" only proceeds when something asks again (a cron `--once`, or the Store);
  the agent has no timer of its own.
