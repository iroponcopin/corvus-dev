ASTRAEA has ended (2026-10-16).
This package holds an empty placeholder (mod id astraea_retired) that replaces ASTRAEA on servers.
It adds no blocks, items or code. You may delete it.
