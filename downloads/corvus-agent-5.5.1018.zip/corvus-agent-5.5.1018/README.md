# Corvus agent (V4)

A small program that keeps a Minecraft Fabric server on the same brand mods as the Corvus Store. It reads the same
manifest the Store reads, checks each downloaded file against the manifest's size and SHA-256, and replaces only the
jars of the brands listed in its configuration.

Status: **5.1.0 (see "Version 5.1.0" below); 5.0.0 managed mode; 4.1.1 behaviour is the default for existing settings.** The 4.0.0 behaviour is still there as "external" mode. See "Not verified" for what
has not been run.

## From Corvus Store (no command prompt)

If you use Corvus Store on the same computer as the server, the Store can do the set-up for you. Open the Store, find
**Corvus Agent**, press its button and choose the server's folder (the folder that contains `mods`, or `server.jar`, or
a start script). The Store downloads the agent, checks it against the published size and SHA-256, and puts it in the
folder as `corvus-agent.jar`. It also writes `corvus-agent.json`, `start-with-corvus.bat` and `start-with-corvus.sh`,
which run `corvus-agent.jar`, and lists the mods it finds in `"brands"`.

If the folder already has a start script from an earlier hand set-up that names a different jar, the Store leaves that
script alone and tells you the one line to change: the jar name must become `corvus-agent.jar`.

From then on, start the server with `start-with-corvus.bat` (or `start-with-corvus.sh` on Linux and macOS). When a new
agent is published, the Store offers an update. It replaces `corvus-agent.jar` and nothing else: the scripts and
`corvus-agent.json` are not touched. If the server is running, the jar is locked (on Windows), so the Store says to
stop the server and press Update again.

Corvus Store 4.1 never started, stopped or talked to the server. From Corvus Store 5 (Corvus Studio) the Store starts the agent (never the server directly), reads its status over the agent's loopback API, and can ask it to shut down; the agent starts and stops the server. The rest of this file is for doing the same by hand.

## The quick way (Windows, a server you start from a .bat)

You run the server by double-clicking a `.bat` file. After these steps the agent starts the server for you, watches it,
and updates the mods by itself.

1. **Install Java 25** if `java -version` (in Command Prompt) shows a version below 25. Use any Java 25 build (for
   example Eclipse Temurin 25) and tick the option that adds Java to the PATH.
2. **Put `corvus-agent-4.1.1.jar` in your server folder**, the folder that contains `mods`, next to your current `.bat`.
3. **Open Command Prompt in that folder** (click the address bar, type `cmd`, press Enter) and run:

       java -jar corvus-agent-4.1.1.jar --init .

   It writes `corvus-agent.json` and `start-with-corvus.bat` into the folder, and tells you what it found. It never
   overwrites an existing `corvus-agent.json`.
4. **Open `corvus-agent.json` in Notepad.** Edit `"brands"`: keep only the brands this server runs. The valid names are
   `cherry`, `ouka`, `astraea`, `tsubomi` and `halia`. The file says `tsubomi` as a placeholder. Check that
   `"serverCommand"` is the command your `.bat` runs (`--init` copies it from the `.bat`). `--init` also reads the `mods` folder and lists the brands it finds.
5. **From now on start the server with `start-with-corvus.bat`** (double-click it), not with the old `.bat`.
6. **What the window shows:** the server's log, exactly as before, with the agent's own lines (with UTC times) in
   between. Type server commands as usual: `say hello`, `op name`.
7. **Stopping:** typing `stop` in the window still stops the server and saves the world. The window then closes by
   itself.
8. **Mods update by themselves.** About every ten minutes the agent checks the site. When a new version is published
   and no player is online, it stops the server, copies the mods folder to a backup, replaces the jars, starts the
   server again, and checks that it answers. If players are online it waits and tries again in ten minutes.
9. **Backups** are in `.corvus-backup\<time>\` inside the server folder. The five newest are kept.

When the agent starts it checks for updates first, installs them, and only then starts the server, so a server that
was switched off over an update comes up on the new mods.

If the server crashes, the agent says so and starts it again after ten seconds (`--init` writes
`"restartOnCrash": true`). After three restarts within ten minutes it gives up, says so, and closes. With
`"restartOnCrash": false` it closes after the first crash. An agent never stays open with no server behind it.

Closing the window or pressing Ctrl+C also stops the server, and the agent asks it to save first. On Windows, Ctrl+C
is delivered to every program in the window, the server included, so use `stop` when you want a clean save.

## Configuration

`corvus-agent.json` is read from `--config <file>`. Relative paths are relative to the file. Unknown fields are refused,
so a typo cannot silently change nothing.

| Field | Mode | Meaning |
| --- | --- | --- |
| `mode` | both | `"managed"`: the agent starts the server as its child and owns its console. `"external"` (default): the agent runs `stopCommand` and `startCommand`. |
| `serverDir` | both | The server folder. Must exist. `mods/` is inside it. Commands run here. |
| `brands` | both | Brand blocks the server runs: `cherry`, `ouka`, `astraea`, `tsubomi`, `halia`. Only these are ever installed or updated. |
| `serverCommand` | managed, required | The command that starts the server, as a list, such as `["java", "-Xmx4G", "-jar", "fabric-server-launch.jar", "nogui"]`. Must not be empty. A `.bat` or `.cmd` is run through `cmd.exe /c`. Ignored in external mode. |
| `pollMinutes` | both | How often the agent syncs on its own. `0` means never (only on request). Default 10 in managed mode, 0 in external mode. |
| `restartOnCrash` | managed | `true` starts the server again after an unexpected exit (after 10 seconds, at most 3 times in 10 minutes), then the agent closes. Default `false`; `--init` writes `true`. |
| `stopCommand` / `startCommand` | external, required | Commands run in `serverDir`. The stop command must end the server; the start command should launch it and return. Ignored in managed mode. |
| `manifestUrl` | both | The manifest address. https only (http only for 127.0.0.1 or localhost). Defaults to the published manifest. |
| `token` | when `listenPort` > 0 | Bearer token for the HTTP endpoint. At least 32 characters. Never printed. |
| `listenHost` / `listenPort` | both | Where the HTTP endpoint listens. `listenPort` `0` means no HTTP endpoint and no token is needed. Default: 0 in managed mode, 8931 in external mode. |
| `statusHost` / `statusPort` | both | Where the Minecraft status ping is sent. Defaults to 127.0.0.1:25565. |
| `startTimeoutSeconds` | both | How long to wait for the server to answer after a start. Default 600. |
| `stopTimeoutSeconds` | both | How long the server may take to stop. Default 60. In managed mode, after this the process is destroyed. |
| `waitForEmptyMinutes` | both | 0 (default): never update while players are online. More than 0: postpone, and proceed after that many minutes. |

## Running

    java -jar corvus-agent-4.1.1.jar --init <serverDir>                   # write a managed configuration (never overwrites)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json --plan    # what would change; changes nothing (both modes)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json --once    # one sync, then exit (external mode only; 0 = done or deferred)
    java -jar corvus-agent-4.1.1.jar --config corvus-agent.json           # stay up

In managed mode `--once` is refused with exit code 2: a one-shot run cannot own a server that keeps running.

Every line is printed with a UTC time. The token is never printed.

## The HTTP endpoint (when `listenPort` is above 0)

Bound to 127.0.0.1 unless the configuration says otherwise.

- `POST /api/v4/sync` with `Authorization: Bearer <token>`: starts one sync in the background. Answers 202 `STARTED`
  or 202 `ALREADY_RUNNING`. The request body is read and ignored.
- `GET /api/v4/status` with the same header: version, brands, whether a run is in progress, the last result.

A wrong or missing token is 401. A sixth wrong attempt from one address within ten minutes is 429 for the next ten
minutes, even with the right token. The endpoint has no TLS of its own: put it behind a proxy or a tunnel to reach it
from the internet.

## The scheduled sync and the one-run rule

The timer (`pollMinutes`) and the HTTP endpoint share one guard: at most one sync runs at a time, whichever asked for
it. The first timer check comes `pollMinutes` after start, so the server has time to boot; the agent logs a plan at
start. A check that finds players online is postponed, and the next check tries again.

## What a sync does, in order

1. Reads the manifest and compares each listed brand with the jar in `mods/` that declares its mod id.
   Nothing to do: the server is not touched.
2. Downloads each needed file to `.corvus-staging/` and checks its size and SHA-256. Any mismatch stops the run;
   nothing is stopped or changed.
3. If players are online, postpones (unless `waitForEmptyMinutes` says to wait).
4. Copies the mods folder to `.corvus-backup/<UTC timestamp>/`: every file in `mods/`, so a roll-back puts back exactly
   what was there.
5. Stops the server. In managed mode the agent writes `stop` to the server's console and waits for the process to exit,
   and destroys it only after `stopTimeoutSeconds`. In external mode the stop command runs and the agent waits for the
   status ping to go silent.
6. Installs each brand with the same installer the Store uses: one jar per mod id, the installer's own checks, and its
   own roll-back.
7. Starts the server and polls its status ping until it answers or the start timeout passes.
8. If the installer failed, or the server did not answer: puts the backup back, starts the server again, and reports it.

Nothing is removed from `mods/` except jars of the listed brands (found by mod id), and the installer's own staging
names. Other mods, and any file a player put there, are byte-identical after a run.

The five newest backups are kept.

## External mode (4.0.0 behaviour)

Set `"mode": "external"`, or leave it out. The agent does not start the server; the stop and start commands do. Use
`corvus-agent.external.example.json` as the starting point. On Windows a `stopCommand` or `startCommand` whose first
element ends in `.bat` or `.cmd` is run through `cmd.exe /c`.

A scheduled run needs no Store: `--once` from cron or a systemd timer, or a `pollMinutes` value above 0.

## Linking Corvus Store

Corvus Store 4.0.0 and later: Account, then "Linked server". Switch it on, give the agent's address and the token from
this configuration, and press "Test connection". After the Store installs or updates a mod it sends one request to the
agent, which then syncs the server to the site's manifest. This needs `listenPort` above 0. Plain `http` is accepted by
the Store only for this computer or a local network address; for a server on the internet put the agent behind an
`https` reverse proxy or a tunnel.

## Verified on a real server (4.0.0, 12 October 2026, macOS, Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.161.0)

- First install from the live site into a running server: Tsubomi 1.1.0 (a bare jar), Cherry 1.2.0 (a ZIP, with its
  GeckoLib) and Halia 1.0.0 were downloaded and verified, the server was stopped, the jars placed, the server started,
  and it answered its status ping with the three mods loaded. Fabric API in the folder was untouched.
- An update: Tsubomi 1.0.1 in a running server became 1.1.0.
- A real roll-back: with a start timeout too short for a real server, the agent stopped the half-started server, put
  the previous jars back (the folder was byte-identical to before), and started it again; one server process was left.
- The HTTP endpoint: no token and a wrong token got 401; the right token started a sync; a second request at once got
  ALREADY_RUNNING; a request body naming another manifest address had no effect; the status reported UPDATED.
- Corvus Store's own client against the running agent: status CONNECTED, a wrong token UNAUTHORISED, sync STARTED.

## Version 5.1.0: retirement without waiting, difficulty and XHard

**Retirement (changed).** The agent removes a retired brand's own jars from the mods folder on the next run, whether or
not `brands` lists it. It finds them by mod id, as it finds a listed brand's jars, and moves them (never deletes) to
`.corvus-retired/<brand>-<yyyyMMdd-HHmmss>/` through the guarded path: player gate, mods backup, world backup, stop, move,
start, health check, roll-back. `remove_after` is still read and shown in the status, but it no longer waits: the
"Version 5.0.1" rule below (the date) is superseded. The journal no longer records `brand_retirement_scheduled`, and no
run reports `RETIRE_PENDING` (the value is kept for JSON readers). Nothing else in `mods/` is read or changed.

**Difficulty.** A new setting, `"difficulty"`: `peaceful`, `easy`, `normal`, `hard` or `xhard`. The Studio's Difficulty
card and `PUT /api/v5/settings` with `{"difficulty": "..."}` set it:
- `peaceful`, `easy`, `normal`, `hard`: `difficulty=<x>` in `server.properties`; when the server answers, the console
  gets `difficulty <x>`. If Corvus XHard is installed, its `enabled` becomes false, and `xhard off` is sent when the server
  answers.
- `xhard`: Corvus XHard (`corvus-xhard-1.0.0.jar`, mod id `corvus_xhard`) is installed from the manifest's `xhard` block
  (size and SHA-256 checked) through the guarded path. A server that is not running is not started; the jar loads on its
  next start. Then `difficulty=hard`, `config/corvus-xhard.json` gets `"enabled": true`, and when the server answers the
  console gets `difficulty hard` and `xhard on`. A missing `xhard` block is refused with a plain sentence, and nothing
  changes.
- XHard is active when it is installed, enabled, and the world is on `hard` (`/api/v5/status`, `difficulty.xhardActive`).

**First start.** A file with no `difficulty` key is switched to `xhard` once, before the first sync, and that is applied.
If that fails (for example, the manifest has no `xhard` block yet), nothing is written and the next start tries again.
Journal events: `difficulty_changed`, `difficulty_failed`, `xhard_installed`.

**Not verified:** no real server has run XHard or a difficulty change; the manifest publishes no `xhard` block yet; the
external mode has no console, so it writes the properties and configuration and the change takes effect at the next start.

## Version 5.0.2: the site moved

The website and its manifest are now at `https://iroponcopin.github.io/corvus-dev/`, so the default `manifestUrl` is `https://iroponcopin.github.io/corvus-dev/glimpse_manifest.json`. A configuration file that still names the previous address is read as the new one for that run and is not rewritten; the agent prints one line saying so. Files written by the Store's set-up leave `manifestUrl` out, so they get the default.

## Version 5.0.1: a retired mod is removed (superseded in part by 5.1.0)

In 5.1.0 the removal no longer waits for `remove_after` and does not need the brand in `brands`; see "Version 5.1.0".

When the manifest marks a mod as retired (a `retired` object with `date`, `remove_after` and `notice_url` in its block),
the agent never installs it again, even when `brands` lists it. If it is installed:

- **Before `remove_after`** (the UTC date) nothing changes. The sync says when it will be removed, the journal records
  `brand_retirement_scheduled` once, and Corvus Studio shows the date on its Dashboard.
- **On or after `remove_after`**, the first sync removes it through the same path as an update: the player gate, the
  mods-folder copy, a world backup, stop, then the mod's own jars are **moved** (never deleted) to
  `.corvus-retired/<mod>-<yyyyMMdd-HHmmss>/`, start, status ping, and a roll-back if the server does not come back.
  This happens even when `autoUpdate` is off. No other file in `mods/` changes: a mod it depended on (OUKA, GeckoLib)
  stays. The journal records `brand_retired_removed`.

Removing a mod removes its blocks, items and dimensions from the world. The world backup taken before the removal
(`.corvus/backups/`) and the moved jar are how to go back. ASTRAEA is the first retired mod (service ended 16 October 2026;
removal on or after 23 October 2026).

Verified on a real server (16 October 2026, macOS, Minecraft 26.3, Fabric 0.19.5) with OUKA 1.6.2 and ASTRAEA 1.5.4:
before the date nothing changed; on the date the world backup held ASTRAEA's dimensions, the jar was moved, the server
started without ASTRAEA, and the other six jars were byte-identical.

## Version 5.0.0: daemon mode, backups, tunnel, management API

Status: **5.0.0 (unverified on a real server; see "Not verified").** New in this version:

- **Daemon mode.** `--daemon`, or managed mode started with no console attached. The server's output goes to
  `<serverDir>/.corvus/logs/server.log` (5 files of 5 MB). Nothing reads the terminal. A server that stops unexpectedly
  is recorded (`server_crashed`) and the agent stays up for the Store to act on.
- **One agent per server folder.** A lock on `<serverDir>/.corvus/agent.lock` is held for the life of the process. A
  second agent exits with code 3 and one sentence, and starts nothing.
- **Event journal.** `<serverDir>/.corvus/events.jsonl`, one JSON object per line (time, kind, sentence, fields),
  rotated at 5 MB, 5 files kept. Fields never hold secrets.
- **World backups.** `<serverDir>/.corvus/backups/<yyyyMMdd-HHmmss>.zip`: the level folder(s) and `server.properties`.
  With the server running the agent sends `save-off`, `save-all flush`, waits for "Saved the game", copies, then sends
  `save-on` (also when the copy fails). Refused when the free disk is under twice the world's size. Only zips the
  agent made (they carry a marker entry) are listed, pruned or restored. The mods-only `.corvus-backup` is unchanged.
- **Update order (managed mode).** World backup, stop, swap mods, start, status ping, tunnel (when enabled); any failure
  rolls the mods back and starts the server again. With `autoUpdate` off an update is recorded (`update_found`) and shown
  as pending, and nothing is downloaded or installed.
- **Tunnel.** `tunnelMode`: `none` (the default), `command` (runs `tunnelCommand` in `tunnelWorkingDir`), or `playit`
  (see "playit" below). Started after the server answers, stopped with the server. For `command`, the output goes to
  `.corvus/logs/tunnel.log`; it is restarted after a crash with a back-off, and after five restarts in ten minutes it
  gives up and says so.
- **Status port.** When `statusPort` is not in the file, the status ping uses `server-port` from the server's own
  `server.properties`, read at every ping (25565 when absent). `--init` writes `statusPort` from that file.
- **Start-up.** The API listener starts before the first sync and start. While those run, `serverState` is `updating`
  or `starting`.
- **Restore.** The current world folders are moved aside into `.corvus/restore-previous/<stamp>/` first, the backup is
  extracted and moved in. If anything fails, the new items are removed and the previous ones are moved back. The aside
  copy is deleted only after success.
- **Management API** (`/api/v5/*`, loopback 127.0.0.1 only in this version, bearer token on every endpoint): `status`,
  `events?after=&limit=`, `logs?source=server|tunnel|agent&lines=`, `settings` (GET, PUT), and
  `actions/{start|stop|restart|backup|update|restore|shutdown}`. `restore` takes `{"id": "...", "confirm": true}`. A
  request while the agent is busy gets 409. `/api/v4/*` is unchanged.
- **Default port.** Managed mode opens the API whenever the configuration has a token, from the console script as well as
  from `--daemon`. `listenPort` 0 or absent then means 8931 (a 4.1 file has `"listenPort": 0`). Without a token there is
  no listener and the agent only runs the server.
- **One server per folder.** Before every start (first start, Start, restart, crash restart, a sync's restart) the agent
  asks the status port whether a server already answers. If one does, and it is not the agent's own child, the agent
  starts nothing, writes the journal event `server_already_running`, and reports `serverState: "external"`. A sync skips
  its update check while such a server answers (`sync_skipped`), and a sync's own restart fails rather than counting a
  foreign server as success. The monitor retries every tick while the server is wanted, and starts it when the other
  server has gone. A stop by the admin clears the wish, so the server stays down.
- **Backups and restores while another server runs.** A backup (manual, scheduled), a restore and an update are refused
  while a foreign server answers: one plain sentence, the journal event `backup_skipped_external`, and the API answers
  409. A scheduled backup is said once, not on every tick.
- **Console mode with a refused start.** The window shows the one sentence "Another server already runs in this folder
  (port N), so this agent did not start one." and nothing else until the other server goes away. Then the agent starts
  the server and says so. Close the other server's window once; the agent does not need a restart.
- **Studio (Corvus Store 5).** Shows "Corvus Agent 4.1 or another program is running this server. Close its window once,
  then press Start." and no Start button while another server answers. Autostart at Store launch does not start an agent
  beside such a server.
- **Start-script migration.** When the Store sets up or updates the agent in a folder whose `start-with-corvus.bat` or
  `start-with-corvus.sh` is exactly the text a 4.1 agent generated (any `corvus-agent*.jar` name), and nothing runs in
  the folder, the script is rewritten to run `corvus-agent.jar` (console mode). Any other script is never rewritten; the
  Store shows the one line to change.
- **Update message.** If the agent jar is locked (Windows), the Store says: "Close the Corvus server window once, then
  press Update again."

### Not verified for 5.0.0 (in addition to the list below)

- The Studio window was not run: no screenshot, no Store launch, no login. The Start and Update buttons were not pressed;
  the migration was run through its function (`AgentScriptMigration.migrate`), not through the Store's Update button.
- The 11 non-English translations of the new strings are unreviewed (English and Japanese are checked).
- Rehearsed on macOS only, with the 4.1.1 jar (not 4.1.0), a Fabric 26.3 server and the fake-free real process. Both
  shapes (`corvus-agent.jar` from the Store, and `corvus-agent-4.1.1.jar` from `--init`) were tested. Windows was not.
- A foreign server that appears during a sync is refused at the sync's restart; that path is tested with a stub, not with
  a real second server appearing mid-update.
- A manual backup while another server runs is refused by the agent, but a world copied by hand is not protected.

### playit (playit.gg)

`tunnelMode: "playit"`. playit is two programs: `playitd` (the daemon that holds the tunnel) and `playit` (the command
that talks to it). On Windows the official installer (`playit-windows-x86_64-signed.msi`, version 1.0.10) puts them in
`%ProgramFiles%\playit_gg\bin\` and creates the Windows service `playitd`. The agent finds `playit.exe` there first,
then on PATH.

**Seen on a real Windows install (run 38537524892, playit 1.0.10, MSI signed by Developed Methods LLC):**
- the folder holds `playit.exe`, `playitd.exe`, `playitd-service.exe`, `playitd-tray.exe`, `playitd-windows-setup.exe`;
- the service `playitd`: `START_TYPE 3 DEMAND_START`, `SERVICE_START_NAME LocalSystem`, binary
  `playitd-service.exe`, `STATE 1 STOPPED` after install (so it can be stopped after a reboot);
- `playit status` with the service stopped: stdout `The playit service is not running.`, exit 0;
- `playit secret-path` with the service stopped: stderr `Could not connect to the playit service. Start it with
  `playit start`, then try again.`, exit 1;
- no `playit.toml` in `%ProgramData%\playit_gg` or the user config folder on a fresh install.

**Policy (the agent never stops a service):**
- **Service (Windows).** When the server is up and the service is stopped, the agent runs `playit start` **once per
  server start**. It never runs `playit stop`. If the start fails (non-zero exit), the agent records a
  `tunnel_needs_attention` event with the sentence "playit could not be started by Corvus; open playit once, or start
  it as an administrator" and the status shows `tunnel.state: "needs_attention"`. It does not retry until the server
  starts again. Whether a standard (non-admin) user may run `playit start` is **not verified**.
- **Supervised daemon (not a service).** Only when `playitd` is found and it is not the Windows service, the agent runs
  `playitd --secret-path <file> --socket-path <.corvus/playit.sock>` as a supervised child, with the restart rules of
  `command`.

**What the agent reads:**
- `playit status`: the stopped line above means stopped. Exit 0 with any other text means running. The source (not
  seen) says the word `WaitingForSecret` means not claimed yet; the claim is otherwise unknown, and the status block
  shows `claimed: null`, `claim: "unknown"`.
- `sc.exe query playitd`: `STATE : 4 RUNNING` or `1 STOPPED` overrides the status for running, when it answers.
- `playit secret-path` is not called by the agent. The secret file is never opened or read; only its path is passed to
  `playitd`. The default path, `%ProgramData%\playit_gg\playit.toml` on Windows and `~/.config/playit_gg/playit.toml`
  elsewhere, is from the source; no file existed on the fresh install that was seen.

The status block has `tunnel.kind`, `installed`, `claimed`, `claim`, `state` (`stopped`, `running`, or
`needs_attention`), `address` (always `null`: the address is never guessed) and `help`
(`https://playit.gg/account/tunnels`). Claiming needs a person in a browser at that address.

**Not verified:**
- A claimed account and a live tunnel (no account was available to the agent's author).
- The wording of a running status (only the stopped line was seen).
- Whether `playit start` works without administrator rights.
- The `WaitingForSecret` / claimed wording, and the secret path once playit is claimed.

Tests: `PlayitTunnelTest` uses the seen lines verbatim as fixtures, and fake `playit` and `playitd` programs for the
start, failure and daemon paths. `sc.exe` is answered by the test, not by the real service.

### Settings written by the API

`PUT /api/v5/settings` writes `corvus-agent.json`. This is the one exception to "never overwrite": the file is edited
as a tree (unknown keys and the `token` are kept) and replaced atomically (temporary file, then move). `--init` still
never overwrites it. The keys: `autoUpdate` (default true), `autoBackup` (default true), `backupIntervalMinutes` (360, 15 to
10080), `backupKeep` (7, 1 to 100), `backupSkipIfIdle` (true), `tunnelCommand`,
`tunnelMode` (none, command or playit), `tunnelCommand`, `tunnelWorkingDir` (blank means the server folder). The API never returns the tunnel's command values, only whether one is
set. Note that the agent still rejects keys it does not know when it loads the file (unchanged from 4.1), so a file
holding a key from a newer version needs that newer agent.

## Not verified

- **Managed mode has not been run against a real Minecraft server, and not on Windows.** Its tests use a fake child
  process (`FakeMinecraftServer`, started with the same Java as the tests) on macOS. The Windows test step is in
  `.github/workflows/windows-tests.yml` and has not been run.
- Typing into the console of a real server through the agent's pass-through, and the window's close and Ctrl+C on
  Windows (see above). A `.bat` run through `cmd.exe /c` with arguments that contain spaces is untested.
- The start scripts (`start-with-corvus.bat`, `start-with-corvus.sh`) have not been double-clicked or run.
- The server's output is read as UTF-8. A server that prints in another encoding on Windows may show odd characters.
- Restarts after a crash of a real server (`restartOnCrash`).
- Linux and Windows servers as the external mode's stop and start commands; systemd, Docker or a hosting panel.
- A server that fails to start because a mod is broken (the roll-back was forced with a short timeout instead).
- The player gate with a real player online (tested with a scripted fake only).
- The endpoint has no TLS of its own. Do not open it to the internet without a proxy or a tunnel in front of it.
- "Wait N minutes while players are online" only proceeds when a later check comes round, which the timer or a request
  makes; the agent does not sleep through the wait.
